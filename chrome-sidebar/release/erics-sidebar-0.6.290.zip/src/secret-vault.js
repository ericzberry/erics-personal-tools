// Protected values (card numbers) that the Worker must never be able to read.
//
// The key is derived from the WebAuthn PRF output of the user's passkey, so it
// exists only on devices holding that passkey and never reaches the cloud. The
// derivation is deliberately deterministic — a fixed PRF salt and HKDF label,
// no stored per-device state — because the same key must open a record on the
// iPhone and in the sidebar. Chrome M122+ lets an extension page claim the RP
// ID of a host it has permission for, so both hosts address one synced passkey.
//
// Losing every copy of that passkey makes protected values unreadable. The
// recovery code is the derived key itself, shown on request so it can be kept
// in a password manager; it is the only way back in, and the only fallback if a
// browser cannot produce PRF output.
import {IDLE_MS, idleSession} from './idle-session.js';
import {CLOUD_URL} from './cloud-storage.js';

export const VAULT_RP_ID = new URL(CLOUD_URL).hostname;
export const RECOVERY_PREFIX = 'EV1';
// Exported because a host may already be asking this passkey for something of
// its own. The mobile app's lock evaluates this salt alongside its own, so one
// biometric check opens the app and the records it holds.
export const PRF_SALT = new TextEncoder().encode('erics-tools/card-secrets/v1/prf-salt');
const HKDF_INFO = new TextEncoder().encode('erics-tools/card-secrets/v1');
const ALPHABET = '0123456789ABCDEFGHJKMNPQRSTVWXYZ';
const bytes = value => new TextEncoder().encode(value);
const random = length => crypto.getRandomValues(new Uint8Array(length));
export const encode = value => btoa(String.fromCharCode(...new Uint8Array(value))).replaceAll('+', '-').replaceAll('/', '_').replaceAll('=', '');
const decode = value => Uint8Array.from(atob(value.replaceAll('-', '+').replaceAll('_', '/')), char => char.charCodeAt(0));

export function recoveryCode(raw) {
  let bits = 0, value = 0, out = '';
  for (const byte of new Uint8Array(raw)) {
    value = (value << 8) | byte; bits += 8;
    while (bits >= 5) { out += ALPHABET[(value >>> (bits - 5)) & 31]; bits -= 5; }
  }
  if (bits) out += ALPHABET[(value << (5 - bits)) & 31];
  return `${RECOVERY_PREFIX}-${out.match(/.{1,13}/g).join('-')}`;
}
export function recoveryBytes(code) {
  const clean = String(code).toUpperCase().replace(/[^0-9A-Z]/g, '').replace(/^EV1/, '')
    .replaceAll('I', '1').replaceAll('L', '1').replaceAll('O', '0');
  let bits = 0, value = 0; const out = [];
  for (const char of clean) {
    const index = ALPHABET.indexOf(char);
    if (index < 0) throw Error('That recovery code contains characters we don’t recognize.');
    value = (value << 5) | index; bits += 5;
    if (bits >= 8) { out.push((value >>> (bits - 8)) & 255); bits -= 8; }
  }
  if (out.length !== 32) throw Error('That recovery code is incomplete. Enter all 52 characters.');
  return new Uint8Array(out);
}

async function keyFrom(raw) {
  return crypto.subtle.importKey('raw', raw, 'AES-GCM', false, ['encrypt', 'decrypt']);
}
async function stretch(seed) {
  const material = await crypto.subtle.importKey('raw', seed, 'HKDF', false, ['deriveBits']);
  return new Uint8Array(await crypto.subtle.deriveBits({name: 'HKDF', hash: 'SHA-256', salt: PRF_SALT, info: HKDF_INFO}, material, 256));
}
// Bound to the record: an envelope moved to another entry fails to open.
const aad = id => bytes(`erics-tools/card-secrets/v1/${id}`);
export async function sealSecret(key, id, payload) {
  const iv = random(12);
  const ciphertext = await crypto.subtle.encrypt({name: 'AES-GCM', iv, additionalData: aad(id)}, key, bytes(JSON.stringify(payload)));
  return JSON.stringify({v: 1, iv: encode(iv), ciphertext: encode(ciphertext)});
}
export async function openSecret(key, id, envelope) {
  let parsed;
  try { parsed = JSON.parse(envelope); } catch { throw Error('This protected value could not be read.'); }
  if (parsed?.v !== 1 || typeof parsed.iv !== 'string' || typeof parsed.ciphertext !== 'string') throw Error('This protected value was saved in an unsupported format.');
  let plaintext;
  try { plaintext = await crypto.subtle.decrypt({name: 'AES-GCM', iv: decode(parsed.iv), additionalData: aad(id)}, key, decode(parsed.ciphertext)); }
  catch { throw Error('This passkey cannot open this protected value. Unlock with the passkey that saved it, or use your recovery code.'); }
  return JSON.parse(new TextDecoder().decode(plaintext));
}
export const isSealed = value => {
  if (!value) return false;
  try { const parsed = JSON.parse(value); return parsed?.v === 1 && typeof parsed.iv === 'string' && typeof parsed.ciphertext === 'string'; }
  catch { return false; }
};

// One vault per host. Every protected section shares it, so a single passkey
// prompt opens all of them and one idle window governs them together — an
// unlock in the ledger keeps the personal records open, and going idle closes
// both. The derived key is deterministic either way; what is shared here is the
// session, not the secret.
let shared=null;
export function sharedVault(options){
  if(!shared)shared=secretVault(options);
  return shared;
}

// One unlocked session per browser, not per page. Finance and Personal each
// open in their own extension tab, so a key held only in one page's memory
// means a fresh passkey check for every navigation and a reload that throws
// the unlock away. The derived key is kept in `chrome.storage.session`: memory
// only, gone when the browser closes, and readable by this extension's own
// pages but never by a web page or content script. That is what makes one
// prompt cover the whole idle window, an unlock in one tab open the others,
// and Lock now close all of them at once. A page host without that area (the
// mobile app, where every tool already shares one page) simply gets no store.
export const SESSION_KEY='vault-session';
// Writing on every interaction would be pointless churn; the stored stamp only
// has to be fresh enough that a new page inherits a sane remainder.
const REFRESH_MS=60000;
export function vaultSessionStore(area=globalThis.chrome?.storage?.session,changes=globalThis.chrome?.storage?.onChanged){
  if(!area?.get)return null;
  return {
    async read(){try{return (await area.get(SESSION_KEY))[SESSION_KEY]||null;}catch{return null;}},
    write(value){try{return Promise.resolve(area.set({[SESSION_KEY]:value})).catch(()=>{});}catch{return Promise.resolve();}},
    clear(){try{return Promise.resolve(area.remove(SESSION_KEY)).catch(()=>{});}catch{return Promise.resolve();}},
    subscribe(callback){changes?.addListener?.((updates,name)=>{if(name==='session'&&updates[SESSION_KEY])callback(updates[SESSION_KEY].newValue||null);});}
  };
}

// Surviving the extension's own reload. `chrome.storage.session` is memory that
// belongs to the extension, so Chrome empties it whenever the extension is
// unloaded — which is every update and every press of Reload. The reader meets
// that as a passkey prompt minutes after they answered one, for a session that
// never ended and a reason nothing on screen explains.
//
// So the same record is kept a second time, somewhere a reload cannot reach,
// sealed rather than written down. The sealing key is generated here, marked
// non-extractable and left in IndexedDB: this extension's pages can seal and
// open with it, and no code — theirs included — can read it back out. The
// sealed record sits in `chrome.storage.local` beside it. Neither half opens
// anything alone.
//
// What this does not do is lengthen the unlock. The record carries the same
// stamp every other copy carries, so it expires on the one idle window, Lock
// now clears it, and the browser starting up clears it (`forgetCarriedSession`,
// from the service worker's `onStartup`). The trade is that for the remainder
// of an idle window the key exists on disk, sealed, where before it existed
// only in memory; a reader of the profile directory alone cannot use it.
export const CARRY_KEY='vault-carry';
export const CARRY_DB='erics-tools-vault';
const CARRY_STORE='seal';
const CARRY_ID='session-seal';
const settle=query=>new Promise((resolve,reject)=>{query.onsuccess=()=>resolve(query.result);query.onerror=()=>reject(query.error);});
function openCarry(indexedDB){
  return new Promise((resolve,reject)=>{
    const opening=indexedDB.open(CARRY_DB,1);
    opening.onupgradeneeded=()=>{opening.result.createObjectStore(CARRY_STORE);};
    opening.onsuccess=()=>resolve(opening.result);
    opening.onblocked=opening.onerror=()=>reject(opening.error||Error('The vault store could not be opened.'));
  });
}
// Two pages unlocking at once must end up sealing with one key, or the record
// one of them wrote is unreadable to the other. Whichever key is stored first
// wins, decided inside a single transaction, and the loser's is discarded.
async function sealingKey(indexedDB,subtle,make){
  const db=await openCarry(indexedDB);
  try{
    const held=await settle(db.transaction(CARRY_STORE,'readonly').objectStore(CARRY_STORE).get(CARRY_ID));
    if(held||!make)return held||null;
    const fresh=await subtle.generateKey({name:'AES-GCM',length:256},false,['encrypt','decrypt']);
    return await new Promise((resolve,reject)=>{
      const transaction=db.transaction(CARRY_STORE,'readwrite');
      const store=transaction.objectStore(CARRY_STORE);
      const existing=store.get(CARRY_ID);
      let chosen=null;
      existing.onsuccess=()=>{chosen=existing.result||fresh;if(!existing.result)store.put(fresh,CARRY_ID);};
      transaction.oncomplete=()=>resolve(chosen);
      transaction.onabort=transaction.onerror=()=>reject(transaction.error||Error('The vault store could not be written.'));
    });
  }finally{db.close();}
}
export function vaultCarriedStore(area=globalThis.chrome?.storage?.local,{indexedDB=globalThis.indexedDB,subtle=globalThis.crypto?.subtle}={}){
  if(!area?.get||!indexedDB?.open||!subtle?.generateKey)return null;
  return {
    async read(){
      try{
        const saved=(await area.get(CARRY_KEY))[CARRY_KEY];
        if(!saved||typeof saved.at!=='number'||typeof saved.iv!=='string'||typeof saved.sealed!=='string')return null;
        const seal=await sealingKey(indexedDB,subtle,false);
        if(!seal)return null;
        return {key:encode(await subtle.decrypt({name:'AES-GCM',iv:decode(saved.iv)},seal,decode(saved.sealed))),at:saved.at};
      }catch{return null;}
    },
    // A record that cannot be sealed is simply not carried: the session store
    // still holds it, and the reload it would have survived asks again.
    async write(value){
      try{
        const seal=await sealingKey(indexedDB,subtle,true);
        const iv=random(12);
        const sealed=await subtle.encrypt({name:'AES-GCM',iv},seal,decode(value.key));
        await area.set({[CARRY_KEY]:{v:1,iv:encode(iv),sealed:encode(sealed),at:value.at}});
      }catch{}
    },
    async clear(){try{await area.remove(CARRY_KEY);}catch{}}
  };
}
// The browser closing ends the session, and the carried copy has to end with
// it. Chrome empties its own session area; this one is on disk, so it is
// emptied here. The sealing key goes too, so nothing sealed under it can be
// opened again even if the record were somehow to survive.
export async function forgetCarriedSession({storage=globalThis.chrome?.storage?.local,indexedDB=globalThis.indexedDB}={}){
  try{await storage?.remove?.(CARRY_KEY);}catch{}
  try{
    const deleting=indexedDB?.deleteDatabase?.(CARRY_DB);
    if(deleting)await new Promise(resolve=>{deleting.onsuccess=deleting.onerror=deleting.onblocked=()=>resolve();});
  }catch{}
}
// One record in two places: the browser's session memory, which every page of
// this extension reads at once and which ends with the browser, and the sealed
// copy that outlives a reload. Reading prefers the live one and falls back to
// the sealed one; writing and clearing reach both, so locking in any page
// closes the carried session as well.
export function vaultStore(live=vaultSessionStore(),carried=vaultCarriedStore()){
  if(!live||!carried)return live;
  return {
    // The first page after a reload puts what it unsealed back into session
    // memory, so the pages that follow it find the record the ordinary way and
    // a change to it is announced to all of them again. Chrome says nothing
    // about a key being removed that was not there, and Lock now in one page
    // has to reach the rest.
    async read(){
      const current=await live.read();
      if(current)return current;
      const kept=await carried.read();
      if(kept)await live.write(kept);
      return kept;
    },
    async write(value){await Promise.all([live.write(value),carried.write(value)]);},
    async clear(){await Promise.all([live.clear(),carried.clear()]);},
    subscribe(callback){live.subscribe(callback);}
  };
}

// Which passkey answered last. A request that names no credential leaves the
// browser to ask which one to use, and a chooser is the wrong thing to show a
// reader who has one passkey — more so when a synced copy or a repeated
// enrollment fills it with entries under the same name. Naming the credential
// that worked turns the routine unlock back into a plain biometric prompt. The
// ID identifies a passkey; it cannot use one, so it is kept in ordinary local
// storage rather than the session area that holds the key.
//
// A named check that fails is indistinguishable from a dismissed prompt — both
// are NotAllowedError — so the ID is marked rather than dropped. The next check
// names nothing, and what answers it says which happened: a different passkey
// means the remembered one is gone, and the very same passkey means it was here
// all along and this browser cannot find it by ID. Chrome does that with a
// passkey held in Apple Passwords: it answers a check that names no credential
// and reports "No passkeys available" for one that names it. Naming then stops
// for good rather than dead-ending the first unlock of every session. A prompt
// dismissed and then answered looks the same and costs the same — the browser's
// own chooser comes back.
export const CREDENTIAL_KEY='vault-credential';
export const SUSPECT='?';
export const UNNAMED='-';
export function vaultCredentialStore(area=globalThis.chrome?.storage?.local,fallback=globalThis.localStorage){
  if(area?.get)return{
    async read(){try{return (await area.get(CREDENTIAL_KEY))[CREDENTIAL_KEY]||null;}catch{return null;}},
    async write(value){try{await area.set({[CREDENTIAL_KEY]:value});}catch{}},
    async clear(){try{await area.remove(CREDENTIAL_KEY);}catch{}}
  };
  if(!fallback?.getItem)return null;
  return {
    async read(){try{return fallback.getItem(CREDENTIAL_KEY)||null;}catch{return null;}},
    async write(value){try{fallback.setItem(CREDENTIAL_KEY,value);}catch{}},
    async clear(){try{fallback.removeItem(CREDENTIAL_KEY);}catch{}}
  };
}

export function secretVault({
  credentials = globalThis.navigator?.credentials,
  origin = globalThis.location?.origin,
  // A web page may only claim its own domain, and in production that domain is
  // already the API host. Only an extension page has to name it explicitly.
  rpId = globalThis.location?.protocol === 'chrome-extension:' ? VAULT_RP_ID : (globalThis.location?.hostname || VAULT_RP_ID),
  subtle = globalThis.crypto?.subtle,
  now, onLock = () => {},
  store = vaultStore(),
  credentialStore = vaultCredentialStore(),
  // A page that cannot raise the passkey sheet itself hands the check to one
  // that can. Chrome's side panel is such a page: the request leaves it and no
  // sheet ever appears, so the section waits on a prompt nobody can see. The
  // delegate resolves once that other page has stored the session this vault
  // then adopts, or rejects with the reason the check failed.
  unlockElsewhere = null
} = {}) {
  const clock = now || Date.now;
  let key = null, raw = null, pending = null, stamp = 0, borrowed = false;
  const session = idleSession({now, onLock: reason => { key = null; if (raw) { raw.fill(0); raw = null; } stamp = 0; borrowed = false; store?.clear(); onLock(reason); }});
  // A remembered credential is named directly, and named as a passkey held on
  // this device, so the browser goes straight to the biometric check. With none
  // remembered the request stays discoverable: the passkey is synced, so any
  // device holding a copy can answer without its ID being known here.
  function allowList(remembered) {
    if (!remembered || remembered === UNNAMED || remembered.startsWith(SUSPECT)) return null;
    try { return [{type: 'public-key', id: decode(remembered), transports: ['internal']}]; }
    catch { return null; }
  }
  async function assertPasskey(allowCredentials) {
    const challenge = random(32);
    const assertion = await credentials.get({publicKey: {
      challenge, rpId, userVerification: 'required', timeout: 60000,
      ...(allowCredentials ? {allowCredentials} : {}),
      extensions: {prf: {eval: {first: PRF_SALT}}}
    }});
    if (!assertion) throw Error('Passkey verification was canceled.');
    const client = JSON.parse(new TextDecoder().decode(assertion.response.clientDataJSON));
    const auth = new Uint8Array(assertion.response.authenticatorData);
    const rpHash = new Uint8Array(await subtle.digest('SHA-256', bytes(rpId)));
    if (client.type !== 'webauthn.get' || client.origin !== origin || client.challenge !== encode(challenge) || client.crossOrigin === true) throw Error('Passkey verification failed. Try again.');
    // User presence and user verification must both be set: a protected value
    // may only appear after a fresh biometric or passcode check.
    if (auth.length < 37 || (auth[32] & 5) !== 5 || !rpHash.every((value, index) => value === auth[index])) throw Error('Passkey verification failed. Try again.');
    const seed = assertion.getClientExtensionResults()?.prf?.results?.first;
    if (!seed || seed.byteLength !== 32) throw Error('This browser or passkey provider cannot derive encryption keys (PRF). Unlock with your recovery code, or use Apple Passwords on iOS 18 / macOS 15 or later.');
    const id = typeof assertion.id === 'string' ? assertion.id : '';
    try { return {key: await stretch(seed), id}; } finally { new Uint8Array(seed).fill(0); }
  }
  async function fromPasskey() {
    const remembered = await credentialStore?.read() || null;
    const allowCredentials = allowList(remembered);
    let answer;
    try { answer = await assertPasskey(allowCredentials); }
    catch (error) {
      // A remembered passkey that cannot answer here — deleted, replaced, or
      // never findable by ID in this browser — must not become a dead end. The
      // next attempt asks the way the first one did, and the ID is kept only as
      // the suspect that attempt's answer identifies (see CREDENTIAL_KEY).
      if (allowCredentials) await credentialStore?.write(SUSPECT + remembered);
      throw error;
    }
    if (answer.id && remembered !== UNNAMED) {
      // The passkey just refused by name answering a check that named nothing
      // is this browser failing to match it, not a passkey that has gone.
      const blind = !allowCredentials && remembered === SUSPECT + answer.id;
      await credentialStore?.write(blind ? UNNAMED : answer.id);
    }
    return answer.key;
  }
  // The other page's session reaches this one through the store, usually by
  // the subscription below before the delegate even settles; reading it back
  // covers a change notification that has not arrived yet.
  async function fromElsewhere() {
    await unlockElsewhere();
    if (!(session.check() && key)) await restore(await store.read());
    if (!(session.check() && key)) throw Error('This section could not be unlocked.');
    return key;
  }
  async function adopt(next, {at = clock(), persist = true, lent = false} = {}) {
    if (raw) raw.fill(0);
    raw = next;
    borrowed = lent;
    key = await keyFrom(raw);
    session.start(at);
    stamp = at;
    // Awaited, so a page that unlocked on another's behalf has stored the
    // session before it reports success.
    if (persist) await store?.write({key: encode(raw), at});
    return key;
  }
  // A stored session is adopted, never trusted blindly: an expired or damaged
  // record is cleared rather than opening the sections it was meant to guard.
  async function restore(saved) {
    if (!saved || typeof saved.at !== 'number' || typeof saved.key !== 'string') return false;
    if (clock() < saved.at || clock() - saved.at >= IDLE_MS) { store?.clear(); return false; }
    let bytes;
    try { bytes = decode(saved.key); } catch { store?.clear(); return false; }
    if (bytes.length !== 32) { store?.clear(); return false; }
    await adopt(bytes, {at: saved.at, persist: false});
    return true;
  }
  // Reading the stored session is asynchronous, so every entry point settles it
  // first. Without that a page would prompt for a passkey it already holds.
  const ready = (async () => {
    if (!store) return;
    await restore(await store.read());
    store.subscribe(async value => {
      if (!value) { if (session.check()) { key = null; if (raw) { raw.fill(0); raw = null; } stamp = 0; session.lock('remote'); } return; }
      if (key && raw && value.key === encode(raw)) { if (value.at > stamp) { session.start(value.at); stamp = value.at; } return; }
      await restore(value);
    });
  })();
  return {
    idleMs: IDLE_MS,
    // Settles once any session stored by another page has been adopted.
    ready,
    available: () => !!(globalThis.isSecureContext && globalThis.PublicKeyCredential && credentials?.get),
    // True while the key is held and the session has not gone idle.
    unlocked: () => session.check() && !!key,
    // True when this session was opened by the host's own lock rather than by a
    // check of its own. A section then has no lock of its own to offer: locking
    // it would ask for a passkey the host has already taken, and the host's lock
    // is what closes it.
    borrowed: () => session.check() && !!key && borrowed,
    touch() { session.touch(); if (key && clock() - stamp >= REFRESH_MS) { stamp = clock(); store?.write({key: encode(raw), at: stamp}); } },
    lock: () => session.lock(),
    // Returns the live key, prompting for the passkey only when the session is
    // locked or has been idle past its window. Concurrent callers — two gated
    // sections opening at once — share one prompt rather than stacking two.
    async key() {
      await ready;
      if (session.check() && key) { this.touch(); return key; }
      if (!pending) pending = (unlockElsewhere && store ? fromElsewhere() : (async () => adopt(await fromPasskey()))()).finally(() => { pending = null; });
      return pending;
    },
    // Opening a sealed value is also the only test of whether the passkey that
    // answered is the one that sealed it: two passkeys for this site derive two
    // different keys, and an assertion succeeds either way. A value that will
    // not open is that test failing, so the remembered credential is forgotten
    // and the next unlock asks again rather than going straight back to it.
    async open(id, envelope) {
      const current = await this.key();
      try { return await openSecret(current, id, envelope); }
      catch (error) { await credentialStore?.clear(); throw error; }
    },
    // The PRF output of an assertion this page has already made, handed over
    // instead of a second one. A host that verified the passkey for its own
    // reasons — the mobile app's lock, unwrapping this device's access token —
    // evaluates PRF_SALT in that same ceremony and passes the result here, so
    // opening a protected section costs no further prompt. The seed is wiped
    // on the way through: only the stretched key is kept.
    async unlockWithPasskeySeed(seed) {
      const material = seed instanceof Uint8Array ? seed : new Uint8Array(seed);
      if (material.byteLength !== 32) throw Error('That passkey did not produce a key for these records.');
      try { return await adopt(await stretch(material), {lent: true}); } finally { material.fill(0); }
    },
    async unlockWithRecoveryCode(code) { await credentialStore?.clear(); return adopt(recoveryBytes(code)); },
    recoveryCode() {
      if (!session.check() || !raw) throw Error('Unlock with your passkey before showing the recovery code.');
      session.touch();
      return recoveryCode(raw);
    }
  };
}
