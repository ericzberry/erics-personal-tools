import {usableCatalogs,usableRewards,cancelledCard} from './card-data.js';
import {RewardsView,RewardGroup,CardBenefits,BalancePanel,readingSummary,OpportunityRow,PointsRow,ValuationForm,REWARDS_VIEWS} from './components/rewards.js';
import {CardMatches} from './components/cards.js';
import {RecordRow,RecordGroup,Button,RowAction,RowLink,EDIT_GLYPH,DELETE_GLYPH,DONE_GLYPH,HIDE_GLYPH,SHOW_GLYPH,OPEN_GLYPH,Note,Link,Stack,ActionGroup,MaskedValue,Option,FormField,setStatus} from './components/ui.js';
import {validateReward,luhnValid,parseCardBenefits,unheldBenefits,CADENCE_LABELS} from './rewards-data.js';
import {sharedVault,sealSecret} from './secret-vault.js';
import {catalogOffers,catalogGroups,catalogCategories,offerUrl,rewardProgram,parseOfferReading,validateProgramCatalog,MAX_CATALOG_BYTES,READ_TEXT} from './program-data.js';
import {parseBalanceReading,matchBalances,balanceRecord,programName,programShort,walletRun,WALLET_RUNS,UNREAD_BALANCE} from './balance-data.js';
import {parseCreditReading,parseBenefitReading,matchCredits,creditRecord,benefitRecord} from './credit-data.js';
import {parseRateReading,matchRates,rateCards,rateCardRecord} from './rate-data.js';
import {loyaltySitePrograms,loyaltyProgramNamed} from './loyalty-sites.js';
import {institutionNamed} from './account-sites.js';
import {aiConnections} from './ai-connection.js';
import {cardAccounts,accountCoverage,coverageLine,walletGaps,applyBindings,bindingFor} from './wallet-data.js';
import {rewardOpportunities,resolutionFor} from './reward-opportunities.js';
import {pointsAccounts,valuationFor} from './points-data.js';
const fields=['kind','name','source','card','value','due','cadence','state','url','notes'];
// A revealed number returns to its masked form on its own, so an unattended
// sidebar does not keep a card number on screen.
const REVEAL_MS=60000;
// The wallet syncs on its own: on open, on reconnect, when the tool is shown
// again, and on this timer while a change is still waiting to reach the cloud.
// Nothing here asks the owner to press a refresh button.
const RETRY_MS=60000;
// The view the owner was last on, kept per device so the tool reopens where
// it was left. A brand-new wallet ignores it and opens on Wallet.
const VIEW_KEY='rewards-view';
const remembered=()=>{try{return globalThis.localStorage?.getItem(VIEW_KEY)||'';}catch{return '';}};
const remember=key=>{try{globalThis.localStorage?.setItem(VIEW_KEY,key);}catch{/* A view not remembered is a view chosen again. */}};
const STATES={available:'Available',activation:'Needs activation',used:'Used',cancelled:'Cancelled'};
const grouped=digits=>digits.replace(/(.{4})/g,'$1 ').trim();
const reason=error=>error?.name==='NotAllowedError'||error?.name==='AbortError'
  ?'Passkey verification was canceled or timed out. Try again when you’re ready.'
  :error?.message||'Protected values could not be unlocked.';
// `programs` is the read-only store of catalogues a reward program publishes,
// filled by whichever browser last visited the program's own site. A host
// without one — a preview, a harness — simply has no offers section.
// `readPage` is the host's ability to read the tab the owner is looking at. The
// sidebar sits beside that tab and supplies it; a full tab and the phone have
// no such page, so they pass nothing and the balance panel never appears.
// `cards` is the Best card store: the terms a card earns on. With it the Pay
// view is mounted — the purchase advisor and the card terms it rests on —
// and coverage can say which cards have no rates.
// `wallet` is the store of the wallet's records about itself: which page name
// is which account, which opportunity was dismissed, what a point is worth.
// Without it those choices are asked again each time and nothing else changes.
// `mountPay` and `mountRates` build the Pay view's two tools on first use;
// the host supplies them so a harness without those tools mounts none.
export function mountRewards(root,{credentials,offline,remote=null,programs=null,readPage=null,cards=null,wallet=null,mountPay=null,mountRates=null,adapter=null,onSettings=()=>{},onChanged=()=>{},vault=sharedVault()}){
  root.replaceChildren(RewardsView());
  const $=id=>root.querySelector(`#${id}`);
  let entries=[],editing=null,busy=false,loaded=false,activeToken='',generation=0;
  let catalogs=[],programCategory='',categorySignature='';
  // The loyalty program whose site is open beside the panel, and what was read
  // off it. A reading is a proposal until it is saved: the figures are shown as
  // they will be stored, and nothing is written by reading.
  // `credits` is the second half of the same reading: what the issuer's own
  // trackers say is left of each recurring credit on the card. `rates` is what
  // the card earns, which belongs to its saved terms rather than the wallet,
  // and `benefits` is everything the page states that carries no figure at all.
  // `held` is the owner's saved cards, read with the wallet so coverage, Pay
  // and For you can lean on them.
  let site=null,balances=null,credits=null,rates=null,benefits=null,held=[];
  // The wallet's own records: bindings, resolutions, valuations, goals.
  let records=[],expanded=false,valuing='';
  let vaultBusy=false,vaultMessage='',vaultOpen=false,clearSecret=false,revealTimer=null,syncFailed=false;
  let found=[],connectionsFor='';
  let payTool=null,ratesTool=null,requestedView='',chosenView=false;
  const connections=aiConnections({load:async token=>(await remote(token,'/v1/ai-connections')).connections,need:'to read a balance off a page or look up a card.'});
  const revealed=new Map();
  const tabs=$('rewards-tabs');
  const status=(text,tone='')=>setStatus($('rewards-status'),text,tone);
  const cardStatus=(text,tone='')=>setStatus($('reward-card-status'),text,tone);
  const action=(label,fn,variant='secondary')=>{const b=Button(label,{variant,size:'compact',disabled:busy||!loaded});b.addEventListener('click',fn);return b;};
  const connectAction=()=>{const b=Button('Connection settings',{variant:'secondary',size:'compact',disabled:busy});b.addEventListener('click',onSettings);return b;};
  const vaultAction=(label,fn,variant='secondary')=>{const b=Button(label,{variant,size:'compact',disabled:vaultBusy});b.addEventListener('click',fn);return b;};
  // A reward's own verbs, at the end of its line and named for the reward they
  // would act on. The two that reach the vault answer to the vault's own busy
  // state rather than to the list's.
  const rowAction=(glyph,label,fn,danger=false)=>RowAction(glyph,label,fn,{danger,disabled:busy||!loaded});
  const vaultRowAction=(glyph,label,fn)=>RowAction(glyph,label,fn,{disabled:vaultBusy});
  const live=()=>entries.filter(entry=>!entry.deleting&&!entry.conflict);
  function forget(){revealed.clear();clearTimeout(revealTimer);revealTimer=null;$('vault-code').replaceChildren();}
  function hold(){clearTimeout(revealTimer);revealTimer=setTimeout(()=>{forget();renderVault();render();},REVEAL_MS);}
  function edit(entry){
    editing={id:entry.id,revision:entry.revision,secret:entry.secret||'',secretHint:entry.secretHint||''};
    clearSecret=false;
    for(const key of fields)$(`reward-${key}`).value=entry[key]||'';
    $('reward-secret-number').value='';$('reward-secret-expiry').value='';
    renderKind();renderSecret();
    tabs.select('wallet');
    $('reward-editor').open=true;$('reward-name').focus();
  }
  function clearForm(){
    editing=null;clearSecret=false;
    for(const key of fields)$(`reward-${key}`).value=key==='kind'?'balance':key==='state'?'available':'';
    $('reward-secret-number').value='';$('reward-secret-expiry').value='';
    setStatus($('reward-form-status'),'');
    renderKind();renderSecret();
  }
  // A card is the thing benefits belong to, so it has no card of its own and no
  // reset period; those controls leave rather than sit there meaning nothing.
  function renderKind(){
    const card=$('reward-kind').value==='card';
    if(card)$('reward-card').value='';
    for(const key of ['card','cadence'])$(`reward-${key}`).closest('.form-field').hidden=card;
  }
  // Editor state for the stored number: an empty input keeps what is saved, so
  // removing a number has to be its own explicit action.
  function renderSecret(){
    const saved=!!editing?.secret&&!clearSecret,shown=editing&&revealed.get(editing.id);
    $('reward-secret-state').hidden=!saved&&!clearSecret;
    $('reward-secret-state').textContent=clearSecret?'The saved number will be removed when you save this entry.'
      :shown?`Saved · ${shown}`
      :saved?`Saved · •••• ${editing.secretHint}. Leave the fields blank to keep it.`:'';
    $('reward-secret-actions').replaceChildren(...(saved?[
      shown?vaultAction('Hide number',()=>{revealed.delete(editing.id);renderSecret();render();})
        :vaultAction('Show number',()=>reveal({id:editing.id,secret:editing.secret})),
      vaultAction('Remove number',()=>{clearSecret=true;renderSecret();},'danger-subtle')
    ]:clearSecret?[vaultAction('Keep number',()=>{clearSecret=false;renderSecret();})]:[]));
  }
  function renderVault(){
    const open=vault.unlocked(),available=vault.available();
    vaultOpen=open;
    // The shared vault can be unlocked from Finance or Personal without Rewards
    // having a single card number of its own — that unlock is not this page's
    // business, so Lock now / recovery controls only appear here when Rewards
    // itself has something protected.
    $('vault-status').closest('section').hidden=!entries.some(e=>e.secret);
    root.querySelector('.rewards-wallet').classList.toggle('vault-locked',!open);
    // Open is the quiet state: no banner announcing it, just readable numbers
    // and the controls that still apply. Only a failed attempt speaks up.
    // A failed attempt is an error. Being locked is the state the section is
    // plainly in, so it is said quietly and wears no tone.
    setStatus($('vault-status'),vaultMessage||(open?''
      :available?'Locked · Your passkey is required to show a card number.'
      :'Locked · This browser cannot use passkeys. Unlock with your recovery code.'),vaultMessage?'error':'');
    $('vault-detail').textContent=open?''
      :'Numbers are sealed with a key only your passkey can derive, so the cloud stores unreadable text. Keep your recovery code safe: without the passkey or that code, a saved number cannot be recovered.';
    $('vault-actions').replaceChildren(...(open
      ?[vaultAction('Lock now',()=>{vault.lock();forget();vaultMessage='';renderVault();render();}),vaultAction('Show recovery code',showRecovery)]
      :[...(available?[vaultAction('Unlock',unlockVault)]:[]),vaultAction('Use recovery code',()=>{$('vault-recovery').hidden=false;$('vault-recovery-code').focus();})]));
  }
  async function vaultRun(operation){
    if(vaultBusy)return false;
    vaultBusy=true;vaultMessage='';renderVault();render();
    try{await operation();return true;}
    catch(error){vaultMessage=reason(error);return false;}
    finally{vaultBusy=false;renderVault();render();renderSecret();}
  }
  const unlockVault=()=>vaultRun(()=>vault.key());
  async function reveal(entry){
    await vaultRun(async()=>{
      const value=await vault.open(entry.id,entry.secret);
      revealed.set(entry.id,[grouped(value.number),value.expiry?`exp ${value.expiry}`:''].filter(Boolean).join(' · '));
      hold();
    });
  }
  function showRecovery(){
    try{
      const code=vault.recoveryCode();
      $('vault-code').replaceChildren(MaskedValue(code),ActionGroup([vaultAction('Hide recovery code',()=>{$('vault-code').replaceChildren();clearTimeout(revealTimer);})],{compact:true}));
      hold();
    }catch(error){vaultMessage=reason(error);renderVault();}
  }
  async function protectedValues(id){
    const number=$('reward-secret-number').value.replace(/[^0-9]/g,''),expiry=$('reward-secret-expiry').value.trim();
    if(!number){
      if(expiry)throw Error('Enter the card number as well, or clear the expiration.');
      return clearSecret?{secret:'',secretHint:''}:{secret:editing?.secret||'',secretHint:editing?.secretHint||''};
    }
    if(!luhnValid(number))throw Error('Check the card number — those digits do not form a valid card number.');
    if(expiry&&!/^(0[1-9]|1[0-2])\/\d{2}$/.test(expiry))throw Error('Enter the expiration as MM/YY.');
    return {secret:await sealSecret(await vault.key(),id,{number,expiry}),secretHint:number.slice(-4)};
  }
  // With nothing to show, the only useful actions are the two ways in, so the
  // empty wallet offers them rather than describing where they are.
  function emptyState(){
    if(!loaded)return [Note('Connect in Settings to load your saved rewards.')];
    if(entries.length)return [Note('No matching rewards.')];
    // The actions say what belongs here; a sentence listing the four kinds of
    // reward said it again in longer form, above the two buttons that offer it.
    return [ActionGroup([...(remote?[action('Add a card',startCard,'primary')]:[]),
      action('Add a reward',startEntry,remote?'secondary':'primary')],{compact:true})];
  }
  function startEntry(){clearForm();$('reward-editor').open=true;$('reward-name').focus();}
  // What a program currently offers, read off its own site. Nothing here writes
  // a catalogue, so a load that fails leaves the section with nothing to show
  // rather than an error the owner cannot act on.
  async function loadPrograms(){
    if(!programs)return;
    try{
      const token=await credentials.get();
      catalogs=token?(await programs.request(token,'/v1/rewards/programs')).records||[]:[];
    }catch{catalogs=[];}
    renderPrograms();
  }
  // The owner's saved card terms, read alongside the wallet: coverage says
  // which cards have none, For you raises those, and Pay compares on them.
  // The device's own copy answers when the cloud will not, and a store that
  // cannot be read at all is Best card's trouble rather than the wallet's.
  async function loadCards(token){
    if(!cards)return;
    try{held=(await cards.request(token,'/v1/cards')).records||[];}
    catch{try{held=await cards.saved(token);}catch{/* The cards saved here are unchanged. */}}
  }
  // The wallet's records about itself, read the same way.
  async function loadRecords(token){
    if(!wallet)return;
    try{records=(await wallet.request(token,'/v1/wallet')).records||[];}
    catch{try{records=await wallet.saved(token);}catch{/* Choices not read are choices asked again. */}}
  }
  // One record per thing it is about: a second decision on the same key
  // replaces the first rather than sitting beside it.
  async function saveRecord(record){
    if(!wallet)return false;
    try{
      const token=await credentials.get();
      if(!token)throw Error('Open Settings to connect this device.');
      const existing=records.find(other=>other.kind===record.kind&&other.key===record.key);
      const id=existing?.id||crypto.randomUUID();
      const result=await wallet.request(token,`/v1/wallet/${id}`,{method:'PUT',value:{...record,revision:existing?.revision??null}});
      records=result.records||records;
      return true;
    }catch(error){status(error.message,'error');return false;}
  }
  // The picker is rebuilt only when the categories themselves change, so
  // choosing one does not replace the control being used.
  function syncCategories(categories){
    const signature=categories.join('|');
    if(signature===categorySignature)return;
    categorySignature=signature;
    if(!categories.includes(programCategory))programCategory='';
    $('programs-filter').replaceChildren(FormField({id:'programs-category',label:'Category',kind:'select',
      options:[{text:'All categories',value:''},...categories.map(name=>({text:name,value:name}))]}));
    const picker=$('programs-category');
    picker.value=programCategory;
    picker.addEventListener('change',()=>{programCategory=picker.value;renderPrograms();});
  }
  function renderPrograms(){
    // No catalogue store, and nothing read yet, come to the same thing: there
    // is nothing on offer to browse, so the drawer is not there at all.
    const catalogsLive=programs?usableCatalogs(catalogs,entries).filter(catalog=>catalog?.offers?.length):[];
    $('programs-browse').hidden=!catalogsLive.length;
    renderForYou();
    if(!catalogsLive.length){$('programs-list').replaceChildren();$('programs-filter').replaceChildren();categorySignature='';return;}
    syncCategories([...new Set(catalogsLive.flatMap(catalogCategories))].sort((a,b)=>a.localeCompare(b)));
    const query=$('programs-search').value;
    const groups=catalogsLive.map(catalog=>({catalog,offers:catalogOffers(catalog,{query,category:programCategory})})).filter(group=>group.offers.length);
    const total=catalogsLive.reduce((count,catalog)=>count+catalog.offers.length,0);
    const shown=groups.reduce((count,group)=>count+group.offers.length,0);
    // The date the whole catalogue was last seen at once. A reading taken on a
    // single offer's page refreshes part of it and does not move this on.
    const read=catalogsLive.map(catalog=>catalog.listedAt||'').filter(Boolean).sort().at(-1);
    // With one program the heading cannot name it, so the status does. With
    // several, each group names itself instead.
    // What is listed, plainly — not a result and nothing to act on, so it
    // takes no tone.
    setStatus($('programs-status'),[catalogsLive.length===1?catalogsLive[0].label:'',
      shown===total?`${total} offer${total===1?'':'s'}`:`${shown} of ${total} offers`,
      read?`read ${read.slice(0,10)}`:''].filter(Boolean).join(' · '));
    // One row per offer, and — unless the owner has already narrowed the list —
    // those rows live inside a group per category with what is new on top, so a
    // catalogue of a hundred offers costs a handful of closed lines instead of
    // a screen the wallet below it never gets past.
    // Under a heading that already names the category, a row that repeats it
    // says nothing — the same word down twenty rows. `New` spans categories and
    // a search does too, so there the category is what tells the rows apart and
    // it stays.
    const offerRow=(catalog,offer,heading='')=>{
      const url=offerUrl(catalog.programId,offer);
      return RecordRow({title:offer.name,
        // The card comes before the category, because which card an offer is
        // on is the thing that decides whether it is any use today.
        detail:[offer.badge,offer.card,offer.category===heading?'':offer.category,offer.dates].filter(Boolean).join(' · '),
        notes:offer.summary,
        actions:url?[RowLink(OPEN_GLYPH,`Open the ${offer.name} offer`,url)]:[]});
    };
    $('programs-list').replaceChildren(...(shown?groups.flatMap(({catalog})=>[
      catalogsLive.length>1?Note(catalog.label):null,
      ...catalogGroups(catalog,{query,category:programCategory}).flatMap(group=>group.flat
        ? group.offers.map(offer=>offerRow(catalog,offer,programCategory))
        : [RewardGroup({title:group.label,
            detail:`${group.offers.length} offer${group.offers.length===1?'':'s'}`,
            open:group.open,
            children:group.offers.map(offer=>offerRow(catalog,offer,group.label))})])
    ].filter(Boolean)):[Note('No matching offers.')]));
  }
  // What is worth doing, in one short ranked list. Every row is a rule over
  // saved records (`reward-opportunities.js`); this only draws it and keeps
  // the owner's answer to each row.
  function renderForYou(){
    const result=loaded?rewardOpportunities({entries:live(),cards:held,catalogs,resolutions:records},{now:new Date()}):{top:[],rest:[],all:[]};
    const catalogsLive=programs?catalogs.some(catalog=>catalog?.offers?.length):false;
    tabs.show('foryou',loaded&&(result.all.length>0||catalogsLive));
    const list=expanded?result.all:result.top;
    const resolve=(item,choice,until='')=>async()=>{
      if(!wallet){status('Connect this device to keep that choice.','alert');return;}
      if(await saveRecord(resolutionFor(item,choice,{until})))renderForYou();
    };
    const rows=list.map(item=>{
      const actions=[
        ...(item.kind==='explore'?[]:[rowAction(DONE_GLYPH,`Done: ${item.title}`,resolve(item,'done'))]),
        rowAction(HIDE_GLYPH,`Not useful: ${item.title}`,resolve(item,'not_useful')),
        ...(item.kind==='explore'?[rowAction(OPEN_GLYPH,`Browse ${item.source} offers`,()=>{$('programs-browse').open=true;$('programs-search').focus();})]
          :item.action?.url?[RowLink(OPEN_GLYPH,`Open the site for ${item.source}`,item.action.url)]
          :item.kind==='gap'&&item.key.startsWith('rates:')?[rowAction(OPEN_GLYPH,`Add the rates for ${item.source}`,()=>{view('pay');$('rewards-rates-drawer').open=true;})]:[])
      ];
      return OpportunityRow(item,{actions});
    });
    $('rewards-foryou').replaceChildren(...(rows.length?rows:loaded&&result.all.length===0&&catalogsLive?[Note('Nothing to do right now.')]:[]));
    $('rewards-foryou-actions').replaceChildren(...(result.rest.length&&!expanded
      ?[action(`More opportunities (${result.rest.length})`,()=>{expanded=true;renderForYou();})]
      :expanded&&result.all.length>result.top.length?[action('Fewer',()=>{expanded=false;renderForYou();})]:[]));
    renderTabs();
  }
  // What the wallet has and has not read, one line per card, and the first
  // page that would fill the largest gap. It never pretends to reach an
  // issuer: the owner opens the page and the sidebar reads it.
  function renderCoverage(){
    const accounts=loaded?cardAccounts(live(),held):[];
    const gaps=walletGaps(accounts,{entries:live(),catalogs});
    const group=$('rewards-coverage-group');
    group.hidden=!accounts.length;
    if(!accounts.length){$('rewards-coverage').replaceChildren();setStatus($('rewards-coverage-status'),'');return;}
    // The reconciliation line: what is here, and what still needs a choice
    // or a reading. Counts, not a percentage, and computed from the records.
    const unread=live().filter(entry=>entry.kind==='balance'&&entry.value===UNREAD_BALANCE).length;
    const undecided=accounts.filter(account=>account.ambiguous).length;
    setStatus($('rewards-coverage-status'),[`${accounts.length} card${accounts.length===1?'':'s'}`,
      undecided?`${undecided} link${undecided===1?'':'s'} need your choice`:'',
      unread?`${unread} balance${unread===1?'':'s'} not read`:'',
      gaps.length?`${gaps.length} thing${gaps.length===1?'':'s'} to read`:'everything read'].filter(Boolean).join(' · '));
    const rows=accounts.map(account=>{
      const coverage=accountCoverage(account,{entries:live(),catalogs});
      const next=gaps.find(gap=>gap.account===account);
      const site=account.entry?siteOf(account.entry):'';
      return RecordRow({title:account.product,meta:account.hint?`•••• ${account.hint}`:'',detail:coverageLine(coverage),
        // The next page to read is a footnote under the coverage, not a line
        // of body text louder than the facts above it.
        extra:next?[Note(next.next)]:[],
        actions:site?[RowLink(OPEN_GLYPH,`Open the site for ${account.product}`,site)]:[]});
    });
    $('rewards-coverage').replaceChildren(...rows);
  }
  // Balances by program, each with what earns into it and what a point is
  // worth on the owner's own value. Nothing is summed across programs.
  function renderPoints(){
    const rows=loaded?pointsAccounts({entries:live(),cards:held,valuations:records}):[];
    tabs.show('points',rows.length>0);
    $('rewards-points').replaceChildren(...rows.map(row=>{
      const editing=valuing===row.id;
      const actions=[
        ...(row.unit==='dollars'?[]:[rowAction(EDIT_GLYPH,`Set what a ${row.label} point is worth`,()=>{valuing=editing?'':row.id;renderPoints();})]),
        ...(row.url?[RowLink(OPEN_GLYPH,`Open the site for ${row.label}`,row.url)]:[])];
      const extra=editing?[ValuationForm(row,{
        onSave:async cents=>{
          try{
            const record=valuationFor(row.currency,cents);
            if(!(record.cents>0))throw Error('Enter what a point is worth, in cents.');
            if(!wallet)throw Error('Connect this device to keep that value.');
            if(await saveRecord(record)){valuing='';renderPoints();}
          }catch(error){status(error.message,'error');}
        },
        onCancel:()=>{valuing='';renderPoints();}})]:[];
      return PointsRow(row,{actions,extra});
    }));
    renderTabs();
  }
  // Which tabs are in the row, and which one the tool opens on. A tab is
  // there while it has something to answer; the first open of an established
  // wallet lands on For you, and after that wherever the owner last was.
  function renderTabs(){
    const canPay=!!mountPay&&loaded&&(held.length>0||live().some(entry=>entry.kind==='card'));
    tabs.show('pay',canPay);
  }
  // Decided once, after the first full load — the wallet, the cards and the
  // catalogues — because which tabs there are is not known before then.
  function settleView(){
    if(!loaded||chosenView)return;
    const wanted=[requestedView,remembered(),'foryou','wallet'].find(key=>REWARDS_VIEWS.includes(key)&&!$(`rewards-tabs-${key}-tab`).hidden);
    if(wanted){chosenView=true;tabs.select(wanted);opened(wanted);}
  }
  // The Pay view's two tools are built the first time the view is opened,
  // never before: building them reads the device's connection and its
  // records, and a wallet that was never asked for Pay owes no such reads.
  function ensurePay(){
    if(!mountPay||payTool)return;
    payTool=mountPay($('rewards-pay'));
    ratesTool=mountRates?.($('rewards-rates'))||null;
  }
  function opened(key){
    if(key==='pay'){ensurePay();payTool?.refresh?.();ratesTool?.refresh?.();}
  }
  function view(key){
    if(!REWARDS_VIEWS.includes(key))return;
    requestedView=key;
    if(!loaded)return;
    if($(`rewards-tabs-${key}-tab`).hidden)return;
    chosenView=true;tabs.select(key);opened(key);
  }
  // Offered only where all three hold: a program's own page beside the panel, a
  // host that can read it, and a connection that can be asked to. Anywhere else
  // the panel is not there to be pressed.
  function renderBalances(){
    const show=!!site&&!!readPage&&!!remote;
    $('balance-panel').hidden=!show;
    if(!show){$('balance-body').replaceChildren();setStatus($('balance-status'),'');return;}
    $('balance-body').replaceChildren(BalancePanel({
      site,programs:loyaltySitePrograms(site),rows:balances||[],credits:credits||[],
      rates:rates||[],benefits:benefits||[],disabled:busy||!loaded,
      cards:usableRewards(entries).filter(entry=>entry.kind==='card'&&!entry.deleting),
      onRead:readSnapshot,onSave:saveSnapshot,onDiscard:discardSnapshot,onChoose:chooseAccount
    }));
  }
  // A row that fit several cards, answered. The answer is kept with the save,
  // so the next reading of that page name files itself.
  function chooseAccount(row,cardId){
    const holder=entries.find(entry=>entry.id===cardId&&entry.kind==='card')||null;
    row.holder=holder;row.ambiguous=!holder;row.chosen=!!holder;
  }
  const balanceStatus=(text,tone='')=>setStatus($('balance-status'),text,tone);
  const discardSnapshot=()=>{balances=null;credits=null;rates=null;benefits=null;renderBalances();balanceStatus('');};
  // One press does the whole errand: read the page beside the panel, turn it
  // into the four things such a page states — the balances, the credit
  // trackers, what the card earns and the benefits carrying no figure — and
  // show them. Nothing is saved yet.
  async function readSnapshot(){
    if(!site||!readPage||!remote||busy)return;
    // Every currency the site states is read in the one press, and so is
    // everything else it states, so the errand is named after the page rather
    // than after one of the four things that come off it.
    const programs=loyaltySitePrograms(site);
    busy=true;render();balanceStatus(`Reading the ${site.source} page…`,'progress');
    try{
      const token=await credentials.get();
      if(!token)throw Error('Open Settings to connect this device.');
      const connection=await connections.id(token);
      // An issuer's own page is read whole rather than for its figures: what
      // it says about the card — what it earns, what can be enrolled in — is
      // mostly not a figure, and a snapshot that keeps only figures throws
      // exactly those away. An airline's or a hotel's page is a balance page
      // and is read the way the ledger reads one.
      const page=await readPage({figures:site.kind!=='issuer'});
      const result=await remote(token,`/v1/ai-connections/${connection}/balance-intake`,
        // `program`, `source` and `unit` name the first of them on their own,
        // so a device that is ahead of the Worker still gets a reading.
        {method:'POST',value:{text:page.text,program:site.label,source:site.source,unit:site.unit,
          programs:programs.map(entry=>({program:entry.label,source:entry.source,unit:entry.unit}))},timeoutMs:130000});
      // Checked here too: the wallet accepts nothing the API has not proved.
      const rows=matchBalances(parseBalanceReading(result,programs),entries);
      // One `taken` set across both lists: a saved benefit may be claimed by a
      // credit or by an untracked benefit, never by both, or the same entry
      // would be proposed twice and saved over itself. A card name the owner
      // once matched to an account is matched the same way again.
      const claimed=new Set();
      const bind=list=>applyBindings(list,records,entries,{adapter:site.id});
      const found=bind(matchCredits(parseCreditReading(result,site.source),entries,claimed));
      const extra=bind(matchCredits(parseBenefitReading(result,site.source),entries,claimed));
      // A rate belongs to a saved card's terms, so the cards are read again
      // only when there is a rate to land on one.
      const read=parseRateReading(result,site.source);
      if(read.length&&cards)await loadCards(token);
      const rated=matchRates(read.filter(row=>!cancelledCard(row.card,entries)),held);
      balances=rows.length?rows:null;credits=found.length?found:null;
      rates=rated.length?rated:null;benefits=extra.length?extra:null;
      // A reading that found something says so by turning the panel into what
      // it found, which already carries the counts and "nothing saved yet".
      // Saying it again underneath is the screen telling the reader what they
      // are looking at. Only a reading that found nothing needs words.
      // The offers a card's page lists are the program's catalogue, not the
      // owner's wallet, so they go where the other catalogue goes and they go
      // straight there: an offer list is read again every time the page is,
      // and reviewing a hundred merchants one by one is not a thing to ask of
      // anyone. A reading of it is always partial — the page loads more as it
      // is scrolled — so it adds and updates and retires nothing.
      const listed=await saveOffers(token,page.url,result);
      balanceStatus(readingSummary({rows,credits:found,rates:rated,benefits:extra}).length
        ?listed?`${listed} offer${listed===1?'':'s'} saved under Browse offers.`:''
        :listed?`${listed} offer${listed===1?'':'s'} saved under Browse offers.`
        :['Nothing to read on that page. Open your account or benefits page and read again.',result.unread||''].filter(Boolean).join(' '),listed?'success':'alert');
    }catch(error){balanceStatus(reason(error),'error');}
    finally{busy=false;render();renderBalances();}
  }
  // The offers off a page whose program keeps its catalogue in the page's text
  // rather than its markup. The fold into what is stored is the Worker's, the
  // same as for a catalogue read by the watcher, because that is the one copy
  // every device writes. A program this page does not belong to, or a reading
  // that found no offers, writes nothing.
  async function saveOffers(token,url,result){
    const program=rewardProgram(url);
    if(!program||program.reading!==READ_TEXT)return 0;
    // The page's own address goes with them, so an offer's link opens the list
    // it is on: an issuer keeps one per card, told apart by an account key the
    // reading never sees and never needs.
    const offers=usableCatalogs([{offers:parseOfferReading(result,program.id,{path:url})}],entries)[0].offers;
    if(!offers.length)return 0;
    const value=validateProgramCatalog({programId:program.id,complete:false,offers});
    await remote(token,`/v1/rewards/programs/${program.id}`,{method:'PUT',value,maxBytes:MAX_CATALOG_BYTES});
    await loadPrograms();
    return offers.length;
  }
  // Saved one at a time through the same validator and queue as a typed edit.
  // A balance that fails leaves itself and the rest in place to be corrected.
  async function saveSnapshot(){
    // Rates are grouped first because a rate with no card of the owner's to
    // land on is not something to save: a reading left holding only those has
    // nothing to write, and saying "Saved." would be saying nothing happened.
    const groups=rateCards(rates||[]);
    if(!balances?.length&&!credits?.length&&!benefits?.length&&!groups.length)return;
    let figures=0,tracked=0,kept=0,termed=0;
    while(balances?.length){
      const [row]=balances,match=row.ambiguous?null:row.match;
      const entry=balanceRecord(row,match);
      if(!await save({...entry,id:match?.id||entry.id,revision:match?.revision??null})){renderBalances();balanceStatus($('rewards-status').textContent,'error');return;}
      balances=balances.slice(1);figures++;
    }
    balances=null;
    // A credit goes through the same validator and queue as a typed benefit,
    // one at a time, so one that fails leaves itself and the rest on screen to
    // be saved again rather than taking the reading down with it. A card the
    // owner chose for a row is kept as a binding for the next reading.
    const keepChoice=async row=>{if(row.chosen&&row.holder&&site)await saveRecord(bindingFor(site.id,row.card,{id:row.holder.id,name:row.holder.name}));};
    while(credits?.length){
      const [row]=credits,match=row.match;
      const entry=creditRecord(row,match,row.ambiguous?null:row.holder);
      if(!await save({...entry,id:match?.id||entry.id,revision:match?.revision??null})){renderBalances();balanceStatus($('rewards-status').textContent,'error');return;}
      await keepChoice(row);
      credits=credits.slice(1);tracked++;
    }
    credits=null;
    // A benefit with no tracker is the same kind of record with one field
    // fewer, so it goes the same way: one at a time, keeping everything the
    // owner already put on an entry it matched.
    while(benefits?.length){
      const [row]=benefits,match=row.match;
      const entry=benefitRecord(row,match,row.ambiguous?null:row.holder);
      if(!await save({...entry,id:match?.id||entry.id,revision:match?.revision??null})){renderBalances();balanceStatus($('rewards-status').textContent,'error');return;}
      await keepChoice(row);
      benefits=benefits.slice(1);kept++;
    }
    benefits=null;
    // Rates are not wallet entries. They are bonus rules on a card saved in
    // Best card, so they go to that store — one card record at a time, through
    // `normalizeCard` and the same queue a card edited by hand passes.
    if(groups.length){
      busy=true;render();
      for(const group of groups){
        if(!await saveCardRates(group)){busy=false;render();renderBalances();return;}
        termed++;
      }
      busy=false;render();
    }
    // A rate that matched no card of the owner's stays on screen: it changes
    // nothing, and it is the one line saying what the card earns.
    rates=rates?.filter(row=>!row.holder)||null;
    if(!rates?.length)rates=null;
    renderBalances();
    balanceStatus(`Saved ${[figures?`${figures} balance${figures===1?'':'s'}`:'',
      tracked?`${tracked} credit${tracked===1?'':'s'}`:'',
      kept?`${kept} benefit${kept===1?'':'s'}`:'',
      termed?`the terms on ${termed} card${termed===1?'':'s'}`:''].filter(Boolean).join(', ')}.`,'success');
  }
  // One card's terms with the page's rates folded in. A rule the card already
  // holds for the same category and purchase method is that rule at a new rate;
  // everything else about it stays the owner's.
  async function saveCardRates({holder,rows}){
    try{
      const token=await credentials.get();
      if(!token)throw Error('Open Settings to connect this device.');
      const record=rateCardRecord(holder,rows);
      const result=await cards.request(token,`/v1/cards/${holder.id}`,{method:'PUT',value:{...record,revision:holder.revision??null}});
      held=result.records||held;
      return true;
    }catch(error){balanceStatus(reason(error),'error');return false;}
  }
  function startCard(){$('reward-card-intake').open=true;$('reward-card-name').focus();}
  // A balance is one line: the program on the left, the figure at the end of
  // it. The program is named by its brand and nothing else — "United", not
  // "United Airlines MileagePlus" — because the run it sits in has already
  // said it is an airline and nobody holds two United currencies. What is not
  // a balance keeps its full name, since a card is a card and a credit is a
  // credit, and there the issuer joins the name only where the name does not
  // already carry the brand: "Hilton Honors", never "Hilton Hilton Honors".
  // Inside a card's group the heading has just named the card, so a benefit
  // filed there is left to its own name.
  const titleOf=(e,inGroup)=>inGroup?e.name:programShort(e)||programName(e.source,e.name);
  // A program the owner has never read has no figure, and an empty place where
  // the figure goes says that better than 26 rows all printing the same three
  // words.
  const figureOf=e=>e.kind==='balance'&&e.value===UNREAD_BALANCE?'':e.value;
  // What is left once the name and the figure have their places: what is true
  // of this row and not of every other one. "Available" is the resting state
  // of the whole wallet — of a card, of a program never read, of every balance
  // in it — so it states nothing. A balance never read says so in words,
  // because an empty figure beside a program can be read as nothing held.
  const metaOf=e=>[
    e.kind==='balance'&&e.value===UNREAD_BALANCE?'Balance not read':'',
    // What the issuer's own tracker last said is left of it. The card's terms
    // stay in the value beside it, because "$25 per month" and "$25 left this
    // month" are different facts and only one of them changes — and when they
    // are the same figure, which is a credit read before its terms were ever
    // researched, the row says it once. A credit with terms and no reading
    // says that too: the allowance is known, what is left of it is not.
    e.remaining&&e.remaining!==e.value?`${e.remaining} left`:'',
    !e.remaining&&['benefit'].includes(e.kind)&&e.cadence&&/\$/.test(String(e.value||''))?'remaining not read':'',
    e.state==='available'?'':STATES[e.state],CADENCE_LABELS[e.cadence]||'',
    e.secretHint?`•••• ${e.secretHint}`:'',e.due?`Due ${e.due}`:'',e.pending?'Waiting to sync':'',
    e.conflict?'Conflict':'',e.deleting?'Pending deletion':''].filter(Boolean).join(' · ');
  // Where a row goes when it is followed. A link the owner typed is theirs and
  // wins; after it the registries answer, because the wallet already knows the
  // page every one of these is printed on — the program's account page for a
  // balance, the institution's for a card. A benefit takes the page of the card
  // that carries it, whether it is filed under one or only names it, since a
  // credit is used on that card. A row nothing recognizes keeps no link rather
  // than sending the owner to a guess.
  const rowKey=value=>String(value||'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim();
  const registrySite=e=>e.kind==='card'
    ?institutionNamed(e.source)||institutionNamed(e.name)
    :loyaltyProgramNamed(e.name,e.source)||institutionNamed(e.source);
  const ownSite=e=>e.url||registrySite(e)?.url||'';
  const siteOf=e=>{
    const own=ownSite(e);
    if(own)return own;
    const card=entries.find(other=>other.kind==='card'&&!other.deleting
      &&(other.id===e.card||rowKey(other.name)===rowKey(e.source)));
    return card?ownSite(card):'';
  };
  function row(e,inGroup){
    const filed=e.kind==='card'?entries.filter(other=>other.card===e.id).length:0;
    // A program awaiting its first reading holds nothing the owner would miss,
    // so pruning the directory down to the programs they actually have costs
    // one press per row. Everything else still asks, because everything else
    // has something in it to lose.
    const unread=e.kind==='balance'&&e.value===UNREAD_BALANCE;
    const remove=rowAction(DELETE_GLYPH,`Delete ${e.name}`,
      unread?()=>save(e,'DELETE'):()=>{confirmation.hidden=false;yes.focus();},true);
    const yes=action('Delete reward',()=>save(e,'DELETE'),'danger');
    const no=action('Keep reward',()=>{confirmation.hidden=true;remove.focus();});
    // Deleting a card leaves its benefits in the wallet rather than taking them
    // with it, which the confirmation has to say before the choice is made.
    const confirmation=Stack([Note(`Delete “${e.name}” from your connected devices?${filed?` Its ${filed} benefit${filed===1?'':'s'} stay in your wallet.`:''}`),ActionGroup([yes,no],{compact:true})],{hidden:true});
    const shown=revealed.get(e.id);
    const actions=[rowAction(EDIT_GLYPH,`Edit ${e.name}`,()=>edit(e)),
      ...(e.secret?[shown
        ?vaultRowAction(HIDE_GLYPH,`Hide the number for ${e.name}`,()=>{revealed.delete(e.id);render();renderSecret();})
        :vaultRowAction(SHOW_GLYPH,`Show the number for ${e.name}`,()=>reveal(e))]:[]),
      ...(e.state!=='used'&&e.kind==='benefit'?[rowAction(DONE_GLYPH,`Mark ${e.name} used`,()=>save({...e,state:'used',updatedAt:new Date().toISOString()}))]:[]),
      ...(siteOf(e)?[RowLink(OPEN_GLYPH,`Open the site for ${e.name}`,siteOf(e))]:[]),remove];
    // A conflict is a question this reward is asking; it waits in words under
    // the line rather than becoming one more glyph on it.
    const decide=e.conflict
      ?[ActionGroup(['local','cloud'].map(choice=>action(choice==='local'?'Keep my change':'Use cloud version',()=>resolve(e.id,choice))),{compact:true})]
      :[];
    return RecordRow({title:titleOf(e,inGroup),figure:figureOf(e),meta:metaOf(e),notes:e.notes,actions,
      extra:[shown?MaskedValue(shown):null,...decide,confirmation]});
  }
  function render(){
    const query=$('rewards-search').value.trim().toLowerCase();
    const hit=e=>[e.name,e.source,e.notes,e.value].join(' ').toLowerCase().includes(query);
    const cardEntries=entries.filter(e=>e.kind==='card'),held=new Set(cardEntries.map(card=>card.id));
    // Looking up the cards the wallet holds is an action about those cards, so
    // it is there while there are some and gone while there are none.
    $('reward-card-sweep').hidden=!remote||!cardEntries.length;
    $('reward-card-sweep').disabled=busy||!loaded;
    // Benefits live inside the card that carries them; a search opens the groups
    // it matched so a benefit is never hidden behind a closed card.
    const groups=cardEntries.map(card=>{
      const filed=entries.filter(e=>e.kind!=='card'&&e.card===card.id);
      return {card,filed,visible:hit(card)?filed:filed.filter(hit),matched:hit(card)||filed.some(hit)};
    }).filter(group=>group.matched);
    const loose=entries.filter(e=>e.kind!=='card'&&!held.has(e.card)&&hit(e));
    // The collapsed line says the one useful thing about the card: what is
    // waiting to be set up, or that its trackers have not been read.
    const summary=group=>{
      if(group.card.state==='cancelled')return [group.card.source,'Cancelled'].filter(Boolean).join(' · ');
      const setup=group.filed.filter(e=>e.state==='activation').length;
      const money=group.filed.filter(e=>e.kind==='benefit'&&/\$/.test(String(e.value||''))&&e.state!=='used');
      const unread=money.filter(e=>!e.remaining).length;
      return [group.card.source,`${group.filed.length} benefit${group.filed.length===1?'':'s'}`,
        setup?`${setup} to set up`:'',money.length&&unread===money.length?'credit balances not read':unread?`${unread} credit${unread===1?'':'s'} not read`:'',
        group.card.secretHint?`•••• ${group.card.secretHint}`:'',group.card.pending?'Waiting to sync':'',
        group.card.conflict?'Conflict':''].filter(Boolean).join(' · ');
    };
    const cardRows=groups.sort((a,b)=>a.card.name.localeCompare(b.card.name)).map(group=>RewardGroup({
      title:group.card.name,
      detail:summary(group),
      open:!!query,
      children:[row(group.card,true),...group.visible.map(e=>row(e,true))]
    }));
    // The wallet is read in two sections — the cards you hold, then the
    // programs — and each program run is one alphabetical column, because a
    // program is looked for by what it is and not by the day it was saved. A
    // run with nothing in it draws no heading.
    const filed=new Map(WALLET_RUNS.map(run=>[run.key,[]]));
    for(const e of loose)filed.get(walletRun(e)).push(e);
    const ordered=[WALLET_RUNS.find(run=>run.key==='cards'),...WALLET_RUNS.filter(run=>run.key!=='cards')];
    const rows=ordered.flatMap(run=>{
      const inRun=run.key==='cards'?cardRows
        :filed.get(run.key).sort((a,b)=>titleOf(a).localeCompare(titleOf(b))).map(e=>row(e));
      return inRun.length?[RecordGroup(run.title,inRun)]:[];
    });
    $('rewards-list').replaceChildren(...(rows.length?rows:emptyState()));
    const picker=$('reward-card'),chosen=picker.value;
    picker.replaceChildren(Option('Not a card benefit',''),...cardEntries.map(card=>Option(card.name,card.id)));
    picker.value=cardEntries.some(card=>card.id===chosen)?chosen:'';
    for(const key of fields)$(`reward-${key}`).disabled=busy||!loaded;
    for(const key of ['number','expiry'])$(`reward-secret-${key}`).disabled=busy||!loaded||vaultBusy;
    $('reward-save').disabled=busy||!loaded;$('reward-cancel').disabled=busy;
    // Finding a card is the one wallet action that needs AI and the network, so
    // it is the one that disappears where neither is available.
    $('reward-card-intake').hidden=!remote;
    $('reward-card-name').disabled=busy||!loaded;
    $('reward-card-find').disabled=busy||!loaded||globalThis.navigator?.onLine===false;
    // The wallet syncs on its own, so the title carries no Refresh. A wallet
    // that never loaded is the one case with something to press.
    $('wallet-actions').replaceChildren();
    $('rewards-connection').replaceChildren(...(loaded?[]:[connectAction()]));
    for(const node of $('balance-panel').querySelectorAll('button'))node.disabled=busy||!loaded;
    renderCoverage();renderPoints();renderForYou();
  }
  async function run(operation){if(busy)return false;busy=true;const current=++generation;render();try{const token=await credentials.get();if(!token)throw Error('Open Settings to connect this device.');if(activeToken&&activeToken!==token){clear();throw Error('Connection changed. This wallet is reloading for the new connection.');}activeToken=token;const result=await operation(token);if(current!==generation)return false;entries=result.records;loaded=true;syncFailed=false;status(result.syncMessage||'','alert');return true;}catch(error){if(current!==generation)return false;syncFailed=true;status(error.message,'error');setStatus($('reward-form-status'),error.message,'error');return false;}finally{busy=false;render();renderVault();}}
  async function save(entry,method='PUT'){
    const success=await run(token=>offline.request(token,`/v1/rewards/${entry.id}`,{method,value:entry}));
    if(success)onChanged();
    return success;
  }
  async function resolve(id,choice){if(await run(token=>offline.resolve(token,id,choice)))onChanged();}
  async function refresh({quiet=false}={}){
    if(busy)return;
    if(!quiet)status(loaded?'Checking for changes…':'Loading rewards…','progress');
    // The cards and the wallet's records are read with the wallet, before it
    // is drawn, so the first drawing already knows what has rates and what
    // was dismissed.
    await run(async token=>{const result=await offline.request(token,'/v1/rewards');await Promise.all([loadCards(token),loadRecords(token)]);return result;});
    await connectionList();await loadPrograms();
    settleView();
  }
  function clear(){generation++;entries=[];editing=null;loaded=false;activeToken='';connectionsFor='';found=[];catalogs=[];balances=null;credits=null;rates=null;benefits=null;held=[];records=[];expanded=false;valuing='';chosenView=false;connections.forget();forget();vault.lock();clearForm();discardFound();status('Open Settings to connect this device.');payTool?.clear?.();ratesTool?.clear?.();render();renderVault();renderPrograms();renderBalances();tabs.select('wallet');}
  // Whether a connection exists at all is the only thing worth saying, and it
  // is checked once per connected device rather than on every automatic sync.
  async function connectionList(){
    if(!remote||!loaded||globalThis.navigator?.onLine===false)return;
    const token=await credentials.get();
    if(!token||connectionsFor===token)return;
    try{
      const note=await connections.note(token);
      connectionsFor=token;
      if(note)cardStatus(note,'alert');
    }catch(error){cardStatus(error.message,'error');}
  }
  // What every lookup needs and neither of them should ask twice for.
  async function lookupReady(){
    if(!remote)throw Error('Looking up a card is not available here.');
    const token=await credentials.get();
    if(!token)throw Error('Open Settings to connect this device.');
    if(globalThis.navigator?.onLine===false)throw Error('Looking up a card needs internet. Add it by hand instead.');
    return {token,connection:await connections.id(token)};
  }
  const lookupCard=(token,connection,name)=>
    remote(token,`/v1/ai-connections/${connection}/card-benefits`,{method:'POST',value:{name},timeoutMs:180000});
  // Every card the wallet already holds, looked up in one press. The intake
  // beside this is for a card the wallet has never heard of; this is for the
  // ones it has, where what is missing is what they give — and what it proposes
  // is only what is missing, because a card filled in by hand or read off its
  // own page already carries some of it.
  //
  // A name that fits more than one real product is the one thing this cannot
  // settle, because settling it means asking, and a sweep that stopped to ask
  // six times is six presses again. Those cards are named at the end and left
  // to the intake, which is where choosing between products belongs.
  async function sweepCards(){
    const cardEntries=usableRewards(entries).filter(entry=>entry.kind==='card'&&!entry.deleting);
    if(!cardEntries.length)throw Error('No saved cards to look up yet. Name one below and it will be researched as it is added.');
    const {token,connection}=await lookupReady();
    const results=[],asked=[],missed=[];
    for(const [index,card] of cardEntries.entries()){
      cardStatus(`Looking up ${card.name} · ${index+1} of ${cardEntries.length}…`,'progress');
      // One card that cannot be researched is not the end of the sweep. An
      // invitation-only card whose issuer publishes nothing, a name research
      // cannot place, a request that timed out: each of those is one card, and
      // the other five are still worth the press. They are named at the end.
      let read;
      try{
        const result=await lookupCard(token,connection,card.name);
        if(result.matches){asked.push(card.name);continue;}
        read=parseCardBenefits(result);
      }catch{missed.push(card.name);continue;}
      const fresh=unheldBenefits(read.benefits,entries.filter(entry=>entry.card===card.id&&!entry.deleting));
      // The card itself is saved again only where research fills a blank in it:
      // what it earns, said in the issuer's words, on a card that never said.
      const value=card.value||read.card.value;
      if(fresh.length||value!==card.value)
        results.push({card:{...card,value,url:card.url||read.card.url,notes:card.notes||read.card.notes},
          benefits:fresh,cardSaved:value===card.value});
    }
    found=results;
    $('reward-card-matches').replaceChildren();
    showFound();
    const total=results.reduce((sum,result)=>sum+result.benefits.length,0);
    const list=names=>names.join(names.length>2?', ':' and ');
    const named=[asked.length?`${list(asked)} fits more than one card — name it below to choose.`:'',
      // A card the issuer publishes nothing about is the one research cannot
      // finish, and the answer to it is the card's own page, which this tool
      // reads beside the panel.
      missed.length?`Nothing came back for ${list(missed)}. Open the card's own page and read it there.`:'']
      .filter(Boolean).join(' ');
    cardStatus([total
      ?`Found ${total} benefit${total===1?'':'s'} your wallet does not have. Review them, then save.`
      :`Nothing new for ${cardEntries.length===1?'that card':'those cards'}.`,named].filter(Boolean).join(' '),
      total?'success':'alert');
  }
  async function researchCard(name){
    const {token,connection}=await lookupReady();
    const result=await lookupCard(token,connection,name);
    // A rough name can name more than one real card, so research answers with
    // the products it could be. Choosing one is the only way a card is read.
    if(result.matches){
      found=[];$('reward-card-review').replaceChildren();
      $('reward-card-matches').replaceChildren(...CardMatches(result.matches,choice=>cardRun(()=>researchCard(choice))));
      cardStatus('That name fits more than one card. Choose the one you hold.','alert');
      return;
    }
    // Validated again here: the wallet accepts nothing the API has not proved,
    // and nothing it stores was shaped by a response it did not check.
    const read=parseCardBenefits(result);
    found=[read];
    $('reward-card-matches').replaceChildren();
    showFound();
    cardStatus(`Found ${read.benefits.length} benefit${read.benefits.length===1?'':'s'}. Review them, then save.`,'success');
  }
  function showFound(){$('reward-card-review').replaceChildren(...CardBenefits(found,{onSave:saveFound,onDiscard:discardFound}));}
  function discardFound(){found=[];$('reward-card-review').replaceChildren();$('reward-card-matches').replaceChildren();cardStatus('');}
  // The card is saved first so its benefits can name it. A failure part way
  // through keeps the benefits that are left in the review list, so nothing
  // researched is lost and saving again finishes the job.
  async function saveFound(){
    if(!found?.length||busy)return;
    const total=found.reduce((sum,result)=>sum+result.benefits.length,0);
    let saved=0;
    for(const [position,result] of found.entries()){
      const {card,benefits,cardSaved}=result;
      // What is left when a save stops part way: this card from where it
      // stopped, and every card after it untouched. Nothing researched is lost,
      // and saving again finishes the job.
      const remaining=(index,done)=>{
        found=[{card,benefits:benefits.slice(index),cardSaved:done},...found.slice(position+1)];
        showFound();cardStatus($('reward-form-status').textContent,'error');
      };
      if(!cardSaved&&!await save(card)){remaining(0,false);return;}
      for(const [index,benefit] of benefits.entries()){
        cardStatus(`Saving benefit ${saved+1} of ${total}…`,'progress');
        if(!await save({...benefit,card:card.id})){remaining(index,true);return;}
        saved++;
      }
    }
    const count=found.length,only=count===1?found[0].card.name:'';
    discardFound();$('reward-card-name').value='';
    cardStatus(only?`Saved ${only} and ${saved} benefit${saved===1?'':'s'}.`
      :`Saved ${saved} benefit${saved===1?'':'s'} across ${count} cards.`,'success');
  }
  async function cardRun(operation){
    if(busy)return;
    busy=true;render();cardStatus('Looking up this card…','progress');
    try{await operation();}catch(error){cardStatus(reason(error),'error');}
    finally{busy=false;render();}
  }
  // One filter per list, each above the list it narrows: the wallet's search
  // narrows what you hold, the offers' search narrows what is on offer.
  $('rewards-search').addEventListener('input',render);
  $('programs-search').addEventListener('input',renderPrograms);
  $('reward-kind').addEventListener('change',renderKind);
  $('reward-cancel').addEventListener('click',()=>{clearForm();$('reward-editor').open=false;});
  $('reward-card-sweep').addEventListener('click',()=>cardRun(sweepCards));
  $('reward-card-form').addEventListener('submit',event=>{event.preventDefault();
    const name=$('reward-card-name').value.trim();
    if(!name){cardStatus('Say which card you have. A rough name is enough.','alert');return;}
    cardRun(()=>researchCard(name));
  });
  $('vault-recovery-cancel').addEventListener('click',()=>{$('vault-recovery-code').value='';$('vault-recovery').hidden=true;});
  $('vault-recovery-submit').addEventListener('click',()=>vaultRun(async()=>{
    await vault.unlockWithRecoveryCode($('vault-recovery-code').value);
    $('vault-recovery-code').value='';$('vault-recovery').hidden=true;
  }));
  $('reward-form').addEventListener('submit',async event=>{event.preventDefault();if(busy||!loaded)return;try{
    const values=Object.fromEntries(fields.map(key=>[key,$(`reward-${key}`).value]));
    if(values.kind==='card')values.card='';
    const base=validateReward({...values,id:editing?.id});
    const entry=validateReward({...base,...await protectedValues(base.id)},base.updatedAt);
    if(await save({...entry,revision:editing?.revision??null})){clearForm();$('reward-editor').open=false;}
  }catch(error){setStatus($('reward-form-status'),reason(error),'error');}});
  // A view chosen by the owner is remembered, and Pay is built on its first
  // opening.
  tabs.addEventListener('click',event=>{
    const button=event.target.closest?.('[role=tab]');
    if(!button)return;
    const key=REWARDS_VIEWS.find(name=>button.id===`rewards-tabs-${name}-tab`);
    if(!key)return;
    chosenView=true;remember(key);opened(key);
  });
  clearForm();render();renderVault();renderPrograms();renderBalances();
  const reconnect=()=>{if(!$('reward-editor').open)refresh({quiet:true});};
  window.addEventListener('online',reconnect);
  // Losing the network takes Find card benefits with it, so the control says so
  // rather than waiting for a press to explain itself.
  window.addEventListener('offline',render);
  document.addEventListener('visibilitychange',()=>{if(!document.hidden)reconnect();});
  // A failed sync or a queued change retries by itself while the tool is on
  // screen. A conflict waits for the owner's choice instead of retrying.
  const retry=setInterval(()=>{
    if(document.hidden||busy||$('reward-editor').open)return;
    if(syncFailed||entries.some(entry=>entry.pending&&!entry.conflict))refresh({quiet:true});
  },RETRY_MS);
  retry?.unref?.();
  for(const type of ['pointerdown','keydown'])root.addEventListener(type,event=>{if(event.isTrusted)vault.touch();},{capture:true,passive:true});
  // The vault expires on its own schedule; reflect an idle lock without waiting
  // for the next interaction.
  const watch=setInterval(()=>{if(vault.unlocked()!==vaultOpen){forget();renderVault();render();renderSecret();}},1000);
  // Keeping the lock state honest must not keep a host process alive.
  watch?.unref?.();
  return {refresh,clear,view,
    // The tab beside the panel, as the host already knows it. Leaving a
    // program's page takes the reading with it: a figure read off one program's
    // site has nothing to say beside another's.
    site(program=null){
      if((program?.id||'')===(site?.id||''))return;
      site=program||null;balances=null;credits=null;rates=null;benefits=null;
      renderBalances();
    },
    stop(){clearInterval(watch);clearInterval(retry);clearTimeout(revealTimer);}};
}
