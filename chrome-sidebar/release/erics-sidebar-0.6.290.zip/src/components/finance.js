import * as UI from './ui.js';
import {ASSET_CLASSES,REGISTRATIONS,VEHICLES,VALUE_SOURCES,WHOLE_SHARE,classLabel,registrationLabel,vehicleLabel,vehicleShort,vehicleFigures,valueSourceLabel,classSide,signed,shareText} from '../finance-data.js';
import {ACCEPTED} from '../statement-text.js';
import {FINANCE_SITES} from '../account-sites.js';
import {OverviewSection,Figure} from './finance-overview.js';
const {Stack,Section,GroupTitle,Note,Notice,Badge,Button,ActionGroup,Disclosure,SettingsGroup,FormField,Form,Strong,Label,Text,ToolTitle,Link,Tabs,Amount}=UI;
export const {money}=UI;

// Where each institution prints its balances. Reaching the figures is its own
// small errand — a bank's own front page is marketing, and the account summary
// is several presses past it — so the page is held here and opened directly.
// These are links and nothing more: no session is held, nothing is signed in
// to, and an institution the owner does not bank with costs a line in a list
// that is closed until they open it.
const KINDS=[['brokerage','Brokerages'],['bank','Banks'],['credit','Credit cards'],
  ['retirement','Retirement'],['private','Private'],['crypto','Crypto'],['other-asset','Other']];
export function AccountPages(sites=[]){
  return KINDS.flatMap(([kind,label])=>{
    const group=sites.filter(site=>site.kind===kind&&site.url);
    return group.length?[Stack([
      Label(label,{className:'account-pages-kind'}),
      Stack(group.map(site=>Link(site.label,site.url,{className:'account-pages-link'})),
        {className:'account-pages-row'})
    ],{className:'account-pages-group'})]:[];
  });
}

export {Figure} from './finance-overview.js';
export const classOptions=()=>ASSET_CLASSES.map(entry=>({text:`${entry.label}${entry.side==='liability'?' (liability)':''}`,value:String(entry.code)}));
export const registrationOptions=()=>REGISTRATIONS.map(entry=>({text:entry.label,value:String(entry.code)}));
export const vehicleOptions=()=>VEHICLES.map(entry=>({text:entry.label,value:String(entry.code)}));
export const sourceOptions=()=>VALUE_SOURCES.map(entry=>({text:entry.label,value:String(entry.code)}));
// An investment's value is somebody's asset. A liability class would be a
// category error here, so it is not offered.
export const investedClassOptions=()=>ASSET_CLASSES.filter(entry=>entry.side==='asset').map(entry=>({text:entry.label,value:String(entry.code)}));
// What a position cost, beside what it is worth: a value with no called capital
// next to it cannot say whether it is a win, which is the whole reason a
// position is not just a line in the private equity total.
//
// Only the parts that have happened. A direct purchase has no commitment, a
// fund that has distributed nothing has returned nothing, and an investment
// signed last week has none of it — three zeros in a row would say only that
// this is a shape with four slots in it.
export const positionFigures=(position,currency,figures=vehicleFigures(position.holding?.vehicle??position.vehicle))=>[
  // Said first, because it changes what every figure after it means: these are
  // this portfolio's share of the vehicle, not the vehicle. A position that is
  // the whole of one says nothing, which is almost all of them.
  (position.share??WHOLE_SHARE)===WHOLE_SHARE?null:['Share of vehicle',shareText(position.share)],
  position.commitment?['Commitment',money(position.commitment,currency)]:null,
  position.contributed?[figures.committed?'Funded':'Invested',money(position.contributed,currency)]:null,
  position.distributed?[figures.committed?'Returned':'Proceeds',money(position.distributed,currency)]:null,
  position.unfunded?['Unfunded',money(position.unfunded,currency)]:null,
  position.multiple===null||position.multiple===undefined?null:['Multiple',`${position.multiple.toFixed(2)}×`]
].filter(Boolean);
// A figure a line, its name beside it. Run together with middots the five of
// them wrapped wherever the width fell — "Funded $341,370 · Returned" on one
// line and "$3,500" on the next — and a reader hunting for what is unfunded
// had to parse a sentence to find it. Read down, they are a small statement.
export const FigureList=(pairs,props={})=>pairs.length?Stack(pairs.flatMap(([name,value])=>[
  Label(name,{className:'figure-list-name'}),Label(value,{className:'figure-list-value'})
]),{className:'figure-list',...props}):null;

// What a property is worth to its owner, beside what it is worth. A house and
// its mortgage reach the totals as two figures in two classes, one of them
// negative, and nothing in a breakdown puts them back together — so the row
// says the three things the value alone cannot: where the number came from,
// what is still owed, and what is left.
//
// Only the parts that exist. A house with nothing owed on it has equity equal
// to its value, and printing that twice would say only that this is a shape
// with three slots in it.
export const propertyDetail=(entry,currency)=>[
  valueSourceLabel(entry.source),
  entry.debt?`Mortgage ${money(entry.debt,currency)}`:'',
  entry.debt?`Equity ${money(entry.equity,currency)}`:''
].filter(Boolean).join(' · ');

// One action group, two kinds of review — extracted rather than written twice
// so the two cannot drift apart. The verbs stand alone: the review above them
// is what they act on, and "Save these capital accounts" only said it again.
function ReviewActions({editing,disabled,onSave,onEdit,onDiscard}){
  const action=(label,variant,handler)=>{
    const node=Button(label,{variant,size:'compact',disabled});
    node.addEventListener('click',handler);
    return node;
  };
  // Ruled off from the figures by a gap. Flush against the last amount, Save
  // read as one more row of the reading rather than what to do about it.
  return ActionGroup([
    action('Save','primary',onSave),
    ...(editing?[]:[action('Edit','secondary',onEdit)]),
    action('Discard','subtle',onDiscard)
  ],{compact:true,className:'action-group action-group--compact review-actions'});
}
// What a reading came to, after the device folded it. A page states an account
// total and the holdings inside it, and those must never be added together; by
// the time a figure reaches this panel that has been settled, so what is shown
// is what would be saved: one amount per portfolio and asset class, every one
// of them editable, because the owner is the only one who can see whether a
// figure is right. Nothing is written by reading.
//
// Whose money it is, then what it is in, then how much: a heading per holder
// and a line per asset class under it, which is the shape the ledger itself is
// read in. It was a flat run of figures, each carrying a line naming the
// portfolio again and the labels it was read off, and an IRA beside a taxable
// brokerage looked the same as two figures in one place.
//
// Nothing explains itself here. The figures are the review, and the status line
// under them already says how many were read and how many were kept.
export function FoldReview({rows=[],editing=false,disabled=false,onSave,onEdit,onDiscard,onAmount}){
  const shared=rows.length&&rows.every(row=>row.asOf===rows[0].asOf)?rows[0].asOf:'';
  // "new" is worth a word when it separates these figures from the ones landing
  // in a portfolio that already exists. The first reading of an institution
  // makes every portfolio in it new, and the word then sits on every heading
  // saying the same thing about all of them, which is what a reader skips.
  const some=rows.some(row=>row.isNew)&&!rows.every(row=>row.isNew);
  // The fold sorts by holder and then by class, so one pass groups them.
  const groups=[];
  for(const [index,row] of rows.entries()){
    const open=groups.at(-1);
    if(open&&open.portfolio===row.portfolio)open.rows.push({row,index});
    else groups.push({portfolio:row.portfolio,name:row.name,isNew:row.isNew,kind:row.kind,rows:[{row,index}]});
  }
  return Stack([
    // The date, and only the date: the figures are counted by being visible,
    // and a row states its own date only when the reading disagreed about one.
    shared?Label(`as of ${shared}`,{className:'snapshot-meta'}):null,
    // What a proposed portfolio is, beside its name. A reading offers half a
    // dozen at once — trusts, a couple's estate, a company, two children — and
    // they arrive as a list of names with nothing saying which is which, while
    // the saved ledger has carried that tag on every heading all along. It is
    // the one thing about a new portfolio the owner cannot check afterwards
    // without opening it.
    ...groups.map(group=>Section([
      Stack([GroupTitle(`${group.name}${group.isNew&&some?' · new':''}`,{className:'record-group-title group-title--name'}),
        group.kind?Badge(registrationLabel(group.kind),{className:'pill portfolio-kind'}):null],{className:'group-name'}),
      ...group.rows.map(({row,index})=>FoldRow(row,{index,editing,dated:!shared,onAmount}))
    ],{className:'record-group snapshot-group'})),
    ReviewActions({editing,disabled,onSave,onEdit,onDiscard})
  ]);
}

// What a capital account statement came to. A statement carries more than a
// figure — the commitment, what has been called against it, what has come back
// and what it is now worth — so the review shows all of it, and every part of
// it is correctable before anything is written. The one thing the owner alone
// can settle is whether the vehicle really is what its paperwork calls itself,
// which is why the kind is a choice here rather than a reading.
export function CapitalReview({rows=[],notes=[],portfolios=[],editing=false,disabled=false,onSave,onEdit,onDiscard,onField}){
  return Stack([
    rows.length?Label(`${rows.length} capital account${rows.length===1?'':'s'}`,{className:'snapshot-meta'}):null,
    ...rows.map((row,index)=>CapitalRow(row,{index,editing,portfolios,onField})),
    ...notes.map(note=>Note(note)),
    ReviewActions({editing,disabled,onSave,onEdit,onDiscard})
  ]);
}
function CapitalRow(row,{index,editing,portfolios,onField}){
  const where=[
    `${row.portfolioName}${row.portfolioIsNew?' · new portfolio':''}`,
    vehicleShort(row.vehicle),
    row.isNew?'new investment':'',
    `as of ${row.asOf}`
  ].filter(Boolean).join(' · ');
  // An edited field is whatever was typed into it, so every figure is read as
  // a number here rather than assumed to be one.
  //
  // The fields hold the statement — the whole vehicle — and the review shows
  // the position, which is this portfolio's share of it. Showing the statement
  // would put a general partner's whole capital account on the screen as the
  // owner's, which is exactly the reading this share exists to correct.
  const num=key=>Number(row[key])||0;
  const share=Number(row.share)||WHOLE_SHARE;
  const part=figure=>Math.round(figure*share/100)/100;
  const commitment=part(num('commitment')),contributed=part(num('contributed'));
  const distributed=part(num('distributed')),value=part(num('value'));
  // The statement's own figure for what is left to call where it stated one,
  // and the subtraction where it did not — the same rule the saved position
  // follows, so the review and the record cannot disagree.
  const derived=Math.max(0,Math.round((commitment-contributed)*100)/100);
  const stated=row.unfunded===null||row.unfunded===undefined||row.unfunded===''?null:part(Number(row.unfunded)||0);
  const flows=positionFigures({vehicle:row.vehicle,share,commitment,contributed,distributed,
    unfunded:stated??derived,
    multiple:contributed>0?Math.round(((value+distributed)/contributed)*100)/100:null},row.currency);
  // Recorded as one kind, sold as another. Said plainly on the row, because
  // saving the statement does not change how the investment is filed.
  const claimed=row.stated&&row.stated!==row.vehicle?`The statement calls this a ${vehicleLabel(row.stated)}.`:'';
  if(!editing)return Stack([
    Stack([Label(row.name),Amount(value,row.currency)],{className:'snapshot-figure'}),
    Note(where),
    FigureList(flows),
    claimed?Note(claimed):null
  ],{className:'snapshot-row'});
  const field=(key,label,kind='text',options)=>{
    const node=FormField({id:`finance-capital-${key}-${index}`,label,kind,...(options?{options}:{})});
    const input=node.querySelector(kind==='select'?'select':'input');
    input.value=String(row[key]??'');
    input.addEventListener(kind==='select'?'change':'input',()=>onField(index,key,input.value));
    return node;
  };
  // Left empty, what is left to call is the subtraction, so the box shows that
  // answer rather than 0.00 — which is what the field does if nothing is typed
  // into it, and is the whole of what a caption underneath would have said.
  const unfundedField=()=>{
    const node=FormField({id:`finance-capital-unfunded-${index}`,label:'Unfunded commitment',kind:'money',
      placeholder:money(derived,row.currency)});
    const input=node.querySelector('input');
    input.value=String(row.unfunded??'');
    input.addEventListener('input',()=>onField(index,'unfunded',input.value));
    return node;
  };
  // A share is typed as a percentage and stored in basis points, so it is the
  // one field that is not simply the row's value in a box.
  const shareField=()=>{
    const node=FormField({id:`finance-capital-share-${index}`,label:'Share held here (%)',kind:'text'});
    const input=node.querySelector('input');
    input.value=shareText(row.share).replace('%','');
    input.addEventListener('input',()=>onField(index,'share',input.value));
    return node;
  };
  // Named for the kind of investment, and without a commitment where the kind
  // has none — unless the statement stated one anyway, which is not hidden.
  const figures=vehicleFigures(row.vehicle);
  const committed=figures.committed||!!num('commitment')||!!Number(row.unfunded);
  return Stack([
    field('name','Investment'),
    field('vehicle','Kind','select',vehicleOptions()),
    field('class','Asset class','select',investedClassOptions()),
    field('portfolio','Portfolio','select',portfolios),
    shareField(),
    field('value',figures.value,'money'),
    committed?field('commitment','Commitment','money'):null,
    field('contributed',figures.contributed,'money'),
    field('distributed',figures.distributed,'money'),
    committed?unfundedField():null,
    field('asOf','As of','date'),
    claimed?Note(claimed):null
  ],{className:'snapshot-row'});
}
// One figure as it would be saved: what it is in, and how much. The holder is
// the heading over it, so the row does not name it again.
//
// A date only when the figures disagree about one: a reading off one page is
// one day's, and that day is stated once above the whole review.
//
// A liability is shown as what it does to the total, the way the ledger already
// shows one. An amount is stored positive and its class carries the sign, so a
// review printing the stored figure put a card's balance on the screen in the
// shape of money held — beside the cash it is owed against, in the same column,
// reading as $15,835 more rather than $15,835 less. The word rides beside it as
// well, because a minus sign is a shape and some readers will not see it.
// What saving this row would do that the figure alone cannot show: write over a
// different amount already on file, or file money already filed from somewhere
// else. The first is fine print; the second is something to decide, so it takes
// the alert tone, and both are said only for the row that raises them.
const consequences=row=>[row.replaces?Note(row.replaces):null,row.twin?Notice(row.twin,{tone:'alert'}):null];
function FoldRow(row,{index,editing,dated,onAmount}){
  const owed=classSide(row.class)==='liability';
  const what=[classLabel(row.class),owed?'liability':'',dated?`as of ${row.asOf}`:''].filter(Boolean).join(' · ');
  if(!editing)return Stack([
    Stack([Label(what),Amount(signed(row),row.currency)],{className:'snapshot-figure'}),
    ...consequences(row)
  ],{className:'snapshot-row'});
  // The field holds the figure the way it is stored and saved: a positive
  // amount under a liability class. Its label is what says which that is, so
  // correcting a debt is typing what is owed rather than negating it.
  const field=FormField({id:`finance-fold-value-${index}`,label:what,kind:'money'});
  const input=field.querySelector('input');
  input.value=String(row.amount);
  input.addEventListener('input',()=>onAmount(index,input.value));
  return Stack([field,...consequences(row)],{className:'snapshot-row'});
}

// The page in front of you, whatever it is. A recognized account site names
// itself and reads under its own name; any other page the host can read is
// offered the same errand. The heading above this says which, so nothing in
// here repeats it.
// What the last reading actually took off the page, as one button that copies it.
//
// The owner and this reader look at the same screen and do not always see the
// same page: a bank drew twenty accounts in front of him out of components, and
// what arrived here was the summary panel and nothing else. So the reading
// keeps its own evidence — what the page was built out of, and the text that
// was sent. It used to open under a disclosure as a transcript nobody reads in
// a sidebar; what it is for is being pasted into a conversation about why the
// reading failed, so it is a Copy button and nothing else.
export function PageSource({text='',shape=null,trimmed=0},clipboard=globalThis.navigator?.clipboard){
  if(!text&&!shape)return null;
  const built=shape?`${shape.elements} elements · ${shape.roots} root${shape.roots===1?'':'s'} · ${shape.grids} grid${shape.grids===1?'':'s'} · ${shape.frames} frame${shape.frames===1?'':'s'}`:'';
  const sent=`${text.split('\n').filter(Boolean).length} lines · ${text.length.toLocaleString('en-US')} characters${trimmed?` · ${trimmed.toLocaleString('en-US')} left out`:''}`;
  const label='Copy what was read';
  const copy=Button(label,{id:'finance-page-source',variant:'secondary',size:'compact'});
  copy.addEventListener('click',async()=>{
    try{
      await clipboard.writeText(`${[built,sent].filter(Boolean).join('\n')}\n\n${text}`);
      copy.textContent='Copied';
    }catch{copy.textContent='Copy is unavailable here';}
    setTimeout(()=>{copy.textContent=label;},2000);
  });
  return copy;
}
export function PagePanel({site,rows=[],editing=false,disabled=false,source=null,onRead,onSave,onEdit,onDiscard,onAmount}){
  const read=Button(site?`Read my ${site.label} accounts`:'Read the accounts on this page',{id:'finance-page-read',variant:'primary',size:'compact',disabled});
  read.addEventListener('click',onRead);
  // The evidence is for a reading that came back empty. One that worked has
  // its figures on the screen, and a copy button beside Save is noise.
  const copy=source&&!rows.length?PageSource(source):null;
  return Stack([
    rows.length?FoldReview({rows,editing,disabled,onSave,onEdit,onDiscard,onAmount}):
      // The button says what it does and the heading says which page. A
      // sentence underneath repeating both is a paragraph nobody reads twice.
      ActionGroup([read,copy].filter(Boolean),{compact:true})
  ],{className:'snapshot-reading'});
}

export function FinanceView({layout='page'}={}){
  const view=Stack([
    ToolTitle('Finance',{actionsId:'finance-actions',statusId:'finance-status'}),
    // Three scopes, one at a time: the page in front of you, what the whole
    // ledger comes to, and the ways of putting a figure in. They used to run
    // down one page, so reaching the ledger meant scrolling past a reading that
    // had nothing to do with it, and "Position" sitting under "E*TRADE" read as
    // E*TRADE's position when it was the estate's. Each is now a tab, and the
    // tab's label is its heading — nothing inside repeats it.
    //
    // This page leads the row, because a panel opened beside a bank page is
    // there for that page. It appears only where there is a page to read, and
    // the ledger appears once it has been asked for, so a quiet arrival shows
    // the reading and the ways in, and nothing of what the owner is worth.
    //
    // Every label names a view. "Add" among them named an action instead, and a
    // row mixing a verb with two nouns read as a row of buttons; "New figures"
    // then named what the owner leaves with rather than what is under the
    // label, and nobody arrives here holding figures — they arrive holding a
    // statement, a number, or nothing but the bank's web address.
    Tabs({id:'finance-tabs',label:'Finance',items:[
      {key:'page',label:'This page',hidden:true,content:
        SettingsGroup({id:'finance-page-block',className:'settings-group snapshot-panel',children:[
          Stack([],{id:'finance-snapshot-body'}),
          Notice('',{id:'finance-snapshot-status'}),
          // A capital account statement read off this page is reviewed here,
          // beside the reading it came from, rather than under a heading about
          // something else.
          Stack([],{id:'finance-capital-page'})
        ]})},
      {key:'ledger',label:'Net worth',content:layout==='panel'?PanelLedger():PageLedger()},
      {key:'add',label:'Figures',content:
        SettingsGroup({id:'finance-add',children:[
          UI.UploadField({id:'finance-drop',inputId:'finance-file',statusId:'finance-file-status',
            label:'Drop a statement',formats:'PDF, CSV, XLSX or image',accept:ACCEPTED.join(','),
            status:'',resetId:'finance-file-clear',resetLabel:'Remove file'}),
          Stack([],{id:'finance-attachment',hidden:true}),
          Note('',{id:'finance-ai-status',role:'status'}),
          // A dropped statement is read the moment it arrives, so there is
          // nothing to press. This is for a file that could not be read then —
          // offline, or a reading that failed — and it is gone once the file
          // has been read: offering to read what was already read is what the
          // old "Read this" did, under the figures it had read.
          ActionGroup([Button('Read',{id:'finance-read',variant:'primary',size:'compact'})],{compact:true,id:'finance-read-actions',hidden:true}),
          Notice('',{id:'finance-intake-status',role:'status'}),
          Stack([],{id:'finance-drafts'}),
          Stack([],{id:'finance-capital-drafts'}),
          // Three records, one errand. A figure is a class and an amount; a
          // private investment is a name, a kind and the four figures a capital
          // account states; a property is an address and what is owed on it. They
          // stay three forms, because folding them together would make one form
          // that is mostly hidden whichever way it is used — but they are not
          // three separate offers. Stacked as three closed drawers under a fourth,
          // they read as a run of unexplained boundaries, and the one being looked
          // for is found only by reading all of them. So which record is being
          // entered is a switch inside one drawer, chosen where it applies, the way
          // the currency and the trend period already are.
          Disclosure('Enter by hand',[
            Stack([],{id:'finance-entry-switch',className:'currency-switch entry-switch'}),
            Form([
            Strong('New figure',{id:'finance-editor-title'}),
            FormField({id:'finance-portfolio',label:'Portfolio',kind:'select',options:[]}),
            Stack([
              FormField({id:'finance-name',label:'Portfolio name',kind:'text',placeholder:'e.g. Eric and Ariana Berry Estate'}),
              FormField({id:'finance-kind',label:'Registration',kind:'select',options:registrationOptions()}),
              FormField({id:'finance-currency',label:'Currency',kind:'text',placeholder:'USD'})
            ],{id:'finance-portfolio-fields',hidden:true}),
            Stack([
              FormField({id:'finance-class',label:'Asset class',kind:'select',options:classOptions()}),
              FormField({id:'finance-amount',label:'Amount',kind:'money',placeholder:'0.00'}),
              FormField({id:'finance-asOf',label:'As of',kind:'date'})
            ],{id:'finance-figure-fields'}),
            Notice('',{id:'finance-form-status',role:'status'}),
            ActionGroup([Button('Save figure',{id:'finance-save',variant:'primary',type:'submit'}),Button('Cancel edit',{id:'finance-cancel',variant:'secondary'})])
            ],{id:'finance-form',className:'form-stack'}),
            Form([
            Strong('New investment',{id:'finance-inv-title'}),
            FormField({id:'finance-inv-portfolio',label:'Portfolio',kind:'select',options:[]}),
            FormField({id:'finance-inv-name',label:'Investment',kind:'text',placeholder:'e.g. Acme Ventures Fund III, L.P.'}),
            FormField({id:'finance-inv-vehicle',label:'Kind',kind:'select',options:vehicleOptions()}),
            FormField({id:'finance-inv-class',label:'Asset class',kind:'select',options:investedClassOptions()}),
            FormField({id:'finance-inv-share',label:'Share held here (%)',kind:'text',placeholder:'100'}),
            // Shown only where there is something to point at. One vehicle
            // states one capital account however many portfolios hold a piece
            // of it, so a position mapped onto one already held takes its
            // figures from there and stops asking for them.
            Stack([FormField({id:'finance-inv-follows',label:'Same vehicle as',kind:'select',options:[]})],
              {id:'finance-inv-follows-field',hidden:true}),
            Stack([
              FormField({id:'finance-inv-commitment',label:'Commitment',kind:'money',placeholder:'0.00'}),
              FormField({id:'finance-inv-value',label:'Capital account value',kind:'money',placeholder:'0.00'}),
              FormField({id:'finance-inv-funded',label:'Funded to date',kind:'money',placeholder:'0.00'}),
              FormField({id:'finance-inv-returned',label:'Returned to date',kind:'money',placeholder:'0.00'}),
              FormField({id:'finance-inv-unfunded',label:'Unfunded commitment',kind:'money',placeholder:'0.00'}),
              FormField({id:'finance-inv-asOf',label:'As of',kind:'date'})
            ],{id:'finance-inv-figures'}),
            Notice('',{id:'finance-inv-status',role:'status'}),
            ActionGroup([Button('Save investment',{id:'finance-inv-save',variant:'primary',type:'submit'}),Button('Cancel edit',{id:'finance-inv-cancel',variant:'secondary'})])
            ],{id:'finance-inv-form',className:'form-stack',hidden:true}),
            Form([
            Strong('New property',{id:'finance-prop-title'}),
            FormField({id:'finance-prop-portfolio',label:'Portfolio',kind:'select',options:[]}),
            FormField({id:'finance-prop-name',label:'Address',kind:'text',placeholder:'e.g. 123 Example St, Town ST 00000'}),
            FormField({id:'finance-prop-link',label:'Zillow page',kind:'text',placeholder:'https://www.zillow.com/homedetails/…'}),
            FormField({id:'finance-prop-value',label:'Market value',kind:'money',placeholder:'0.00'}),
            FormField({id:'finance-prop-source',label:'Value from',kind:'select',options:sourceOptions()}),
            FormField({id:'finance-prop-debt',label:'Still owed',kind:'money',placeholder:'0.00'}),
            FormField({id:'finance-prop-asOf',label:'As of',kind:'date'}),
            Notice('',{id:'finance-prop-status',role:'status'}),
            ActionGroup([Button('Save property',{id:'finance-prop-save',variant:'primary',type:'submit'}),Button('Cancel edit',{id:'finance-prop-cancel',variant:'secondary'})])
            ],{id:'finance-prop-form',className:'form-stack',hidden:true}),
            // Cash put into an institution or taken out of it. It moves no
            // balance — the next reading does that — and exists so a firm handed
            // $500,000 is not read as a firm that earned it. Which way the money
            // went is a switch, not a sign the owner has to remember to type.
            Form([
            Strong('',{id:'finance-flow-title',hidden:true}),
            FormField({id:'finance-flow-firm',label:'Institution',kind:'select',options:[]}),
            Stack([],{id:'finance-flow-direction',className:'currency-switch entry-switch',role:'group','aria-label':'Which way the cash went'}),
            FormField({id:'finance-flow-amount',label:'Amount',kind:'money',placeholder:'0.00'}),
            FormField({id:'finance-flow-asOf',label:'Date',kind:'date'}),
            Notice('',{id:'finance-flow-status',role:'status'}),
            ActionGroup([Button('Save cash movement',{id:'finance-flow-save',variant:'primary',type:'submit'}),Button('Cancel edit',{id:'finance-flow-cancel',variant:'secondary'})])
            ],{id:'finance-flow-form',className:'form-stack',hidden:true})
          ],{id:'finance-entry'}),
          // Closed until it is wanted. Getting to the figures is a way of putting
          // one in the ledger, which is the scope this tab already has.
          Disclosure('Open an account page',AccountPages(FINANCE_SITES),{id:'finance-account-pages'})
        ]})},
      // How each figure got here: every accepted reading, newest first, and
      // what became of what it saved. A view of its own, because "where did
      // this number come from" is a different question from what the ledger
      // comes to, and it is asked on the page, not in the panel. Shown once
      // there is an import to show.
      ...(layout==='page'?[{key:'imports',label:'Imports',hidden:true,content:
        SettingsGroup({id:'finance-imports-block',children:[Stack([],{id:'finance-imports',className:'travel-list'})]})}]:[])
    ]})
  ],{className:`finance-ledger finance-ledger--${layout}`});
  return view;
}

// The side panel's answer to what it all comes to, and nothing more: the
// figure and the day it stands at, how much of it could be sold this week, and
// what each entity holds. Every line of the ledger — the classes inside each
// entity, the positions, the houses, the quarters — is on the page Open
// details goes to, where there is room to read it. The panel keeps the ways a
// figure gets in, beside the account page the figure comes from.
function PanelLedger(){
  return SettingsGroup({id:'finance-ledger',children:[
    Stack([],{id:'finance-currency-switch',className:'currency-switch',hidden:true}),
    Stack([],{id:'finance-totals',className:'finance-totals finance-totals--panel'}),
    Note('',{id:'finance-change',className:'footnote finance-change',hidden:true}),
    Notice('',{id:'finance-stale',hidden:true}),
    Stack([],{id:'finance-liquidity'}),
    Stack([],{id:'finance-breakdown'}),
    ActionGroup([Button('Open details',{id:'finance-details',variant:'secondary',size:'compact'})],
      {compact:true,id:'finance-details-actions',className:'action-group action-group--compact finance-details-actions',hidden:true})
  ]});
}

// The whole ledger, for a page with room to lay it out: the figure and its
// line over time first, then where the money is, then who holds it, then the
// private positions and the houses side by side, and last each quarter and
// each institution. Every section is open, because nothing on a page this
// wide has to be put away to reach the next thing.
function PageLedger(){
  return Stack([
    Stack([],{id:'finance-currency-switch',className:'currency-switch',hidden:true}),
    Stack([],{id:'finance-hero'}),
    Notice('',{id:'finance-stale',hidden:true}),
    OverviewSection({id:'finance-breakdown-panel',title:'Allocation',hidden:true,children:[Stack([],{id:'finance-breakdown'})]}),
    // Who holds it, and beside it what it has come to quarter by quarter: the
    // two summaries a reader moves between, and the list is read at a width
    // where a name and its total are still one line apart rather than a trip
    // across the screen.
    Stack([
      OverviewSection({id:'finance-entities-panel',title:'Entities',children:[Stack([],{id:'finance-list',className:'travel-list'})]}),
      OverviewSection({id:'finance-trend-panel',title:'Value over time',children:[Stack([],{id:'finance-trend'})]})
    ],{className:'overview-pair'}),
    // How each place the money is held has done, with the cash that went in or
    // out taken back out. A figure is filed under whose money it is, so where
    // it sits survives only in the firm the figure carries — and a figure
    // entered by hand carries none. Absent until a firm has been read or has
    // had cash recorded against it.
    OverviewSection({id:'finance-firms-panel',title:'Institutions',hidden:true,children:[Stack([],{id:'finance-firms'})]}),
    OverviewSection({id:'finance-positions-panel',title:'Private investments',hidden:true,children:[Stack([],{id:'finance-positions'})]}),
    OverviewSection({id:'finance-properties-panel',title:'Real estate',hidden:true,children:[Stack([],{id:'finance-properties'})]}),
    // What every total above rests on: each figure it adds up, the day it was
    // observed and what stated it, taken apart by source, by entity or by
    // class — so any total the page draws can be opened down to its figures.
    // Last, because it is where a number above is checked rather than read.
    OverviewSection({id:'finance-sources-panel',title:'Sources',hidden:true,
      aside:Stack([],{id:'finance-sources-by',className:'currency-switch',role:'group','aria-label':'Take the figures apart by'}),
      children:[Stack([],{id:'finance-sources',className:'travel-list'})]})
  ],{id:'finance-ledger',className:'finance-overview'});
}

// One portfolio, its own total, and a line per asset class. The date sits with
// the figure it belongs to, because a portfolio whose cash was marked last week
// and whose stocks were marked last year is two different ages of information.
// The portfolio's own verbs ride on its heading line beside the total, the way
// a figure's do on its own line, rather than trailing the run as a stray row of
// words that reads as one more figure.
// What kind of account it is rides on the heading as a tag, beside the name it
// qualifies. "Taxable" set as a grey word under the heading belonged to
// nothing the eye could find — it read as a label for the figures below it
// rather than as what the account is.
//
// The date is stated once, above, for the whole ledger. A portfolio repeats it
// only when its own newest figure is older than that, and a line inside it only
// when that line is older still. A date printed on every line was the same fact
// written six times, and it was what made the list unreadable.
// The ledger is read at the level of the entities that hold the money: seven
// names and seven totals, not seven names and forty class lines. A portfolio
// opens to show what is inside it, one at a time, and closed it still says the
// one thing it is there to say. What the heading cannot leave behind goes in
// the summary with it — a date behind the rest of the ledger, or a portfolio
// still waiting to reach the cloud, are facts about the entity and would be
// hidden by the very row that should be reporting them.
// `share` is the part of the whole the entity holds, printed before its total
// the way a breakdown line prints one, so seven totals are also read as seven
// proportions without anyone dividing in their head.
// One accepted reading and what it put in the ledger, closed to its heading the
// way a portfolio is: what was read, what kind of thing it was, and when and how
// much — including how much of it has since been written over, which is what a
// reader needs before deciding to open it. Inside, one line per figure: where it
// went, what it was saved as, and only what is worth knowing beside that — the
// amount it was read as when the owner changed it, the amount it replaced, and
// the source lines it was added up from. UI-28.
export function ImportGroup({name,kind='',meta='',lines=[],note='',open=false,onToggle}){
  const heading=Stack([
    Stack([GroupTitle(name,{className:'record-group-title group-title--name'}),
      kind?Badge(kind,{className:'pill portfolio-kind'}):null,
      meta?Note(meta):null],{className:'group-name'})
  ],{className:'breakdown-row group-line'});
  const group=Disclosure(heading,[
    // What qualifies a figure is fine print under it, one fact to a line. UI-39.
    ...lines.map(line=>{
      const [detail='',...more]=line.notes.filter(Boolean);
      return UI.RecordRow({title:line.what,meta:line.meta,figure:Amount(line.amount,line.currency),detail,extra:more.map(text=>Note(text))});
    }),
    note?Note(note):null
  ].filter(Boolean),{className:'record-group portfolio-group import-group'});
  group.open=open;
  group.addEventListener('toggle',()=>onToggle?.(group.open));
  return group;
}

export function PortfolioGroup({name,kind='',meta,total,currency,rows,actions=[],open=false,onToggle,share=''}){
  // The heading is a name, a number and the portfolio's own two verbs, which
  // ride at its end exactly as a class figure's ride at the end of its line —
  // the same component, the same slot, the same behaviour under a pointer and
  // under a finger. They sat at the foot of the opened block for one release,
  // which put a rule and twelve pixels of nothing between the last figure and
  // a pair of glyphs belonging to the name three lines above them. A row of
  // verbs on a line of its own belongs to nothing the eye can find. UI-33.
  const verbs=ActionGroup(actions,{compact:true,className:'action-group action-group--compact record-actions'});
  // The heading is a summary, so a press anywhere in it opens the group. A
  // verb is the exception: it acts on the portfolio rather than opening it,
  // and the button's own handler has already run by the time this fires.
  verbs.addEventListener('click',event=>{event.preventDefault();});
  const heading=Stack([
    Stack([GroupTitle(name,{className:'record-group-title group-title--name'}),
      kind?Badge(kind,{className:'pill portfolio-kind'}):null,
      meta?Note(meta):null],{className:'group-name'}),
    Stack([share?Label(share,{className:'breakdown-share'}):null,Amount(total,currency),verbs],{className:'group-figure'})
  ],{className:'breakdown-row group-line'});
  const group=Disclosure(heading,[...rows],{className:'record-group portfolio-group'});
  group.open=open;
  group.addEventListener('toggle',()=>onToggle?.(group.open));
  return group;
}

// A breakdown is a proportion, so every line shows the one it is: its share
// drawn behind the row, and the percentage beside the amount. Without it the
// list was four columns of money that the reader had to divide in their head
// against a total further up the screen.
//
// A line that comes to nothing is left out. The ledger never deletes a figure —
// a reading corrected later is superseded by a zero under the same portfolio,
// class and date — so a zeroed class is a figure no longer held, not a holding
// worth nothing, and it has no place in a breakdown of what is held.
//
// `shares` is off where the rows are not parts of one whole: what a private
// investment committed, funded, returned and is worth do not add up to
// anything, and a percentage of their sum would be arithmetic about nothing.
export function BreakdownList(title,rows,currency,{shares=true}={}){
  const live=rows.filter(row=>Math.round(row.total*100)!==0);
  const whole=shares?live.reduce((total,row)=>total+Math.max(0,row.total),0):0;
  return Stack([
    GroupTitle(title,{className:'record-group-title'}),
    ...(live.length?live.map(row=>{
      const share=whole>0&&row.total>0?row.total/whole:0;
      return Stack([
        Label(row.label,{className:'breakdown-name'}),
        share?Label(share<0.005?'<1%':`${Math.round(share*100)}%`,{className:'breakdown-share'}):null,
        Amount(row.total,currency)
      ],{className:'breakdown-row breakdown-line',...(share?{style:`--share:${(share*100).toFixed(1)}%`}:{})});
    }):[Note('Nothing recorded yet.')])
  ],{className:'breakdown-group'});
}

export const quarterOf=asOf=>`${asOf.slice(0,4)} Q${Math.floor((Number(asOf.slice(5,7))-1)/3)+1}`;

// The series as quarters: each quarter shown by the last reading taken in it,
// marked complete when that reading holds every figure the newest one does,
// and starting at the first quarter that does — a quarter from before the
// ledger was first whole is not part of its history. `x` is the quarter's place
// on a time axis, so a quarter nobody read is a gap rather than a point skipped.
export function quarterPoints(series){
  if(!series.length)return [];
  // The newest point carries every figure the ledger holds, because a figure
  // stands until a later one replaces it. So it is the measure of a full
  // reading, and an older point is partial exactly when it holds fewer.
  const whole=series.at(-1).figures;
  // A later reading in the same quarter replaces the earlier one in the map,
  // so each quarter keeps the last reading taken in it.
  const points=[...new Map(series.map(point=>[quarterOf(point.asOf),point])).values()];
  const marked=points.map(point=>({...point,label:quarterOf(point.asOf),complete:point.figures>=whole,
    x:Number(point.asOf.slice(0,4))*4+Math.floor((Number(point.asOf.slice(5,7))-1)/3)}));
  return marked.slice(marked.findIndex(point=>point.complete));
}
// What the newest full quarter did against the full quarter before it — the
// one comparison worth leading with. Nothing until there are two to compare.
export function quarterChange(points){
  const full=points.filter(point=>point.complete);
  return full.length>1?{amount:Math.round((full.at(-1).net-full.at(-2).net)*100)/100,since:full.at(-2).label}:null;
}

// Value over time, read off a ledger that is still being filled in.
//
// Two dated points are only comparable when the same figures stand behind both.
// A reading taken while half the accounts were still to be entered is not a
// smaller net worth, it is a smaller ledger, and subtracting one from the other
// announced a two-million-dollar rise that never happened. So every point says
// how much of the ledger it covers, and a change is drawn only between two
// points that cover all of it.
//
// Quarterly, and only quarterly: that is the grain these figures have. A
// quarter is shown by its last reading — the one with everything in it — and
// the part-filled days spent getting there stop being rows of their own. A
// daily grain was offered beside it and answered nothing a quarter did not;
// when there is enough history to be worth a shape, it gets a chart, not a
// second list of the same numbers.
export function TrendTable(series,currency){
  if(!series.length)return Note('No dated figures yet.');
  const whole=series.at(-1).figures;
  const rows=quarterPoints(series).slice(-12);
  const full=rows.filter(row=>row.complete);
  const change=full.length>1?full.at(-1).net-full[0].net:null;
  const headline=change!==null?`${money(change,currency)} ${change<0?'lower':'higher'} than ${full[0].label}.`:'';
  let previous=null;
  return Stack([
    headline?Note(headline):null,
    ...rows.map(row=>{
      const delta=row.complete&&previous?row.net-previous.net:null;
      if(row.complete)previous=row;
      return Stack([
        Label(row.label),
        Amount(row.net,currency),
        // Partial coverage is said in words, never in a colour: this point is
        // missing figures the newest one has, and that is why no change is
        // drawn against it.
        Note(row.complete?(delta===null?'':`${delta>=0?'+':''}${money(delta,currency)}`)
          :`${row.figures} of ${whole} figures`)
      ],{className:`trend-row${row.complete?'':' trend-row--partial'}`});
    })
  ],{className:'trend-table'});
}
