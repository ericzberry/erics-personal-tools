import {FinanceView,FinanceGroup,BreakdownList,TrendTable,DraftRow,SnapshotPanel,Figure,money,AttachmentCard} from './components/finance.js';
import {RecordRow,Button,Note,Stack,ActionGroup,MaskedValue} from './components/ui.js';
import {attachFileDrop} from './components/file-drop.js';
import {readStatement,trimForReading,ACCEPTED,MAX_BYTES,MAX_SEND} from './statement-text.js';
import {MAX_PAGE_TEXT} from './finance-page-read.js';
import {normalizeFinance,financeSummary,financeCurrencies,netWorthSeries,groupFinanceRecords,valueHistory,parseFinanceUpdates,matchFinanceUpdates,kindLabel,FINANCE_KINDS,effectiveValue} from './finance-data.js';
import {mountVaultGate,vaultReason} from './vault-gate.js';
import {sealSecret} from './secret-vault.js';
const core=['kind','name','institution','owner','value','asOf'];
const extra=['currency','ownership','liquidity','rate','commitment','unfunded','tags','notes'];
const REVEAL_MS=60000;
const today=()=>new Date().toISOString().slice(0,10);

// `readPage` is the host's ability to read the tab the owner is looking at.
// The sidebar sits beside that tab and supplies it; a full tab and the phone
// have no such page, so they pass nothing and the action never appears.
export function mountFinance(root,{credentials,offline,remote,readPage=null,onSettings=()=>{},onChanged=()=>{},vault,quiet:hushed=false,clipboard=globalThis.navigator?.clipboard}){
  const gate=mountVaultGate(root,{
    id:'finance-vault',title:'Finance',
    // A tool built because the tab beside the panel is a finance page raises no
    // passkey sheet of its own. The mode is settled here rather than a moment
    // after mounting, so the prompt cannot get out first.
    automatic:!hushed,
    ...(vault?{vault}:{}),
    onChange:unlocked=>{unlocked?refresh():clear();}
  });
  gate.content.replaceChildren(FinanceView());
  const $=id=>gate.content.querySelector(`#finance-${id}`);
  let records=[],editing=null,busy=false,loaded=false,activeToken='',generation=0,currency='USD',drafts=[],revealTimer=null,clearSecret=false,connection='';
  // The account site the owner is already signed in to beside the panel, and
  // what was read off it. A snapshot is a proposal until it is saved, exactly
  // like a draft: the amounts stay editable and nothing is written by reading.
  let site=null,snapshot=null,snapshotEditing=false;
  // Arriving because the tab is a finance page is not the owner asking to see
  // what they are worth. Such an arrival is quiet: the intake is ready for what
  // the page in front of them can put into the ledger, and the ledger's own
  // figures are not there to be read over a shoulder until one press asks for
  // them. Asking is remembered for the sitting, and forgotten when the section
  // locks, so the answer is not given again on every bank page.
  let quiet=hushed,engaged=false;
  // A picture has no text to show, so it is held here and described instead.
  // Text out of a dropped file goes straight into the box, where it can be
  // read, corrected, or thrown away before anything is sent. An open page is
  // not copied there: it is already in front of the owner.
  let attachment=null;
  const revealed=new Map();
  const status=(text,target='status')=>{$(target).textContent=text||'';};
  const action=(label,handler,variant='secondary')=>{
    const button=Button(label,{variant,size:'compact',disabled:busy||!loaded});
    button.addEventListener('click',handler);
    return button;
  };
  const toolAction=(label,handler)=>{
    const button=Button(label,{variant:'secondary',size:'compact',disabled:busy});
    button.addEventListener('click',handler);
    return button;
  };
  function forget(){revealed.clear();clearTimeout(revealTimer);revealTimer=null;}
  function hold(){clearTimeout(revealTimer);revealTimer=setTimeout(()=>{forget();render();},REVEAL_MS);}

  function clearForm(){
    editing=null;clearSecret=false;
    $('kind').value='bank';$('liquidity').value='Liquid';
    for(const key of ['name','institution','owner','value','rate','commitment','unfunded','tags','notes'])$(key).value='';
    $('currency').value=currency;$('ownership').value='100';$('asOf').value=today();
    $('secret-number').value='';$('secret-expiry').value='';
    $('editor-title').textContent='New record';
    renderSecret();status('','form-status');
  }
  function fill(record){
    editing={id:record.id,revision:record.revision,secret:record.secret||'',secretHint:record.secretHint||''};
    clearSecret=false;
    for(const key of [...core,...extra])$(key).value=record[key]===null||record[key]===undefined?'':String(record[key]);
    $('secret-number').value='';$('secret-expiry').value='';
    $('editor-title').textContent=`Editing ${record.name}`;
    renderSecret();
    $('editor').open=true;$('name').focus();
  }
  // An empty account-details input means "keep what is stored". Removing saved
  // details has to be its own explicit action.
  function renderSecret(){
    const saved=!!editing?.secret&&!clearSecret,shown=editing&&revealed.get(editing.id);
    $('secret-state').hidden=!saved&&!clearSecret;
    $('secret-state').textContent=clearSecret?'The saved account details will be removed when you save this record.'
      :shown?`Saved · ${shown}`
      :saved?`Saved · ${editing.secretHint}. Leave the fields blank to keep them.`:'';
    $('secret-actions').replaceChildren(...(saved?[
      shown?action('Hide details',()=>{revealed.delete(editing.id);renderSecret();render();})
        :action('Show details',()=>reveal({id:editing.id,secret:editing.secret})),
      action('Remove saved details',()=>{clearSecret=true;renderSecret();},'danger-subtle')
    ]:clearSecret?[action('Keep saved details',()=>{clearSecret=false;renderSecret();})]:[]));
  }
  async function protectedValues(id){
    const number=$('secret-number').value.trim(),hint=$('secret-expiry').value.trim();
    if(!number){
      if(hint&&!editing?.secret)throw Error('Enter the account details as well, or clear the hint.');
      return clearSecret?{secret:'',secretHint:''}:{secret:editing?.secret||'',secretHint:editing?.secretHint||''};
    }
    if(!hint)throw Error('Add a short, non-identifying hint so this record can be recognized without unlocking it.');
    return {secret:await sealSecret(await gate.key(),id,{number}),secretHint:hint};
  }
  async function reveal(record){
    await run(async()=>{
      const payload=await gate.open(record.id,record.secret);
      revealed.set(record.id,payload.number);
      hold();
    });
  }
  async function copy(record){
    if(!clipboard?.write||typeof ClipboardItem==='undefined'){status('Copy is unavailable in this browser. Use Show details instead.');return;}
    await run(async()=>{
      const value=gate.open(record.id,record.secret).then(payload=>new Blob([payload.number],{type:'text/plain'}));
      await clipboard.write([new ClipboardItem({'text/plain':value})]);
      status('Account details copied to the clipboard.');
    });
  }

  function renderPosition(){
    const currencies=financeCurrencies(records);
    if(currencies.length&&!currencies.some(entry=>entry.currency===currency))currency=currencies[0].currency;
    $('currency-switch').hidden=currencies.length<2;
    $('currency-switch').replaceChildren(...(currencies.length<2?[]:currencies.map(entry=>{
      const button=Button(`${entry.currency} (${entry.count})`,{variant:entry.currency===currency?'primary':'secondary',size:'compact','aria-pressed':String(entry.currency===currency)});
      button.addEventListener('click',()=>{currency=entry.currency;renderPosition();});
      return button;
    })));
    const summary=financeSummary(records,{currency});
    $('totals').replaceChildren(
      Figure({label:'Net',value:money(summary.net,currency),tone:summary.net<0?'negative':''}),
      Figure({label:'Assets',value:money(summary.assets,currency)}),
      Figure({label:'Liabilities',value:money(summary.liabilities,currency)}),
      ...(summary.unfunded?[Figure({label:'Unfunded',value:money(summary.unfunded,currency)})]:[])
    );
    $('stale').hidden=!summary.stale.length;
    $('stale').textContent=summary.stale.length?`${summary.stale.length} record${summary.stale.length===1?'':'s'} not updated in over 90 days — the oldest is ${summary.stale[0].name}${summary.stale[0].asOf?` from ${summary.stale[0].asOf}`:''}. Totals still include ${summary.stale.length===1?'it':'them'} at ${summary.stale.length===1?'its':'their'} last known value.`:'';
    $('breakdown').replaceChildren(
      BreakdownList('By type',summary.byKind,currency),
      BreakdownList('By owner',summary.byOwner,currency),
      BreakdownList('Assets by liquidity',summary.byLiquidity,currency)
    );
    $('trend').replaceChildren(TrendTable(netWorthSeries(records,{currency}),currency));
    // Currencies are never added together, so say what a total covers.
    $('breakdown-panel').querySelector('summary').textContent=currencies.length>1?`Breakdown · ${currency} only`:'Breakdown';
  }

  function renderAttachment(){
    $('attachment').hidden=!attachment;
    $('attachment').replaceChildren(...(attachment?[AttachmentCard({
      label:attachment.label,detail:attachment.detail,note:attachment.note,
      tone:attachment.tone,onRemove:()=>{attachment=null;renderAttachment();render();}
    })]:[]));
  }
  // Text and pictures take different routes on purpose. Extracted text is put
  // in front of the owner verbatim, because a bad extraction is obvious there
  // and invisible anywhere else. A picture can only be described.
  async function receive(file){
    const result=await readStatement(file);
    if(result.kind==='image'){
      attachment={kind:'image',image:result.image,label:file.name,
        detail:`Image · ${result.image.width}×${result.image.height} · ${Math.round(result.image.bytes/1000)} KB after downscaling on this device`,
        note:'',tone:''};
      renderAttachment();render();
      return 'Ready to read. Add a note below if the picture needs context.';
    }
    if(!result.text.trim()){
      attachment=null;renderAttachment();render();
      throw Error(result.note||'Nothing readable came out of that file.');
    }
    const {text,trimmed}=trimForReading(result.text);
    $('intake').value=text;
    attachment={kind:'text',label:file.name,
      detail:`Text pulled out on this device · ${text.length.toLocaleString('en-US')} characters${result.pages?` · ${result.pages} section${result.pages===1?'':'s'}`:''}`,
      note:[result.note,trimmed?`${trimmed.toLocaleString('en-US')} characters past the ${MAX_SEND.toLocaleString('en-US')}-character limit were left out. Trim the box to what matters.`:''].filter(Boolean).join(' '),
      tone:result.confidence==='good'?'':'warning'};
    renderAttachment();render();
    return result.confidence==='good'?'Check the text below, then read it.':'Check the text below carefully before reading it.';
  }
  // One press does the whole errand. The page is not copied into the box on
  // the way through: it is open beside the panel, where the owner can see it
  // better than any transcript of it, and what comes back — one draft per
  // account, saved only when applied — is the readout worth looking at.
  async function intakeFromPage(){
    await run(async token=>{
      const id=await connectionId(token);
      status('Reading the accounts on the open page…','intake-status');
      const page=await readPage();
      const result=await remote(token,`/v1/ai-connections/${id}/finance-intake`,{method:'POST',value:{text:page.text,today:today(),live:true},timeoutMs:130000});
      const parsed=parseFinanceUpdates(result);
      drafts=matchFinanceUpdates(parsed.updates,records);
      renderDrafts();
      status([drafts.length?`${drafts.length} account${drafts.length===1?'':'s'} read from ${page.host}. Nothing is saved until you apply one.`:`No account values were found on ${page.host}.`,
        page.trimmed?`The page was longer than the ${MAX_PAGE_TEXT.toLocaleString('en-US')}-character limit, so the end of it was left out.`:'',
        parsed.unread].filter(Boolean).join(' '),'intake-status');
    },'intake-status');
  }

  // Rebuilt only when the snapshot itself changes, so editing an amount is not
  // interrupted by an unrelated render. `syncSnapshot` keeps the controls in
  // step with a busy or disconnected tool without replacing them.
  function renderSnapshot(){
    $('snapshot').hidden=!site;
    if(!site){$('snapshot-body').replaceChildren();return;}
    $('snapshot-body').replaceChildren(SnapshotPanel({
      site,rows:snapshot||[],editing:snapshotEditing,disabled:busy||!loaded,
      onStore:storeSnapshots,onSave:saveSnapshots,
      onEdit:()=>{snapshotEditing=true;renderSnapshot();},
      onDiscard:()=>{snapshot=null;snapshotEditing=false;renderSnapshot();status('','snapshot-status');},
      onAmount:(index,value)=>{snapshot[index].value=value;}
    }));
  }
  function syncSnapshot(){
    for(const node of $('snapshot').querySelectorAll('button,input'))node.disabled=busy||!loaded;
  }
  // One press does the whole errand: read the page beside the panel, turn it
  // into one figure per account, and show them. Nothing is saved yet.
  async function storeSnapshots(){
    if(!site||!readPage)return;
    await run(async token=>{
      const id=await connectionId(token);
      status(`Reading your ${site.label} accounts…`,'snapshot-status');
      const page=await readPage();
      const result=await remote(token,`/v1/ai-connections/${id}/finance-intake`,{method:'POST',value:{text:page.text,today:today(),live:true,institution:site.institution},timeoutMs:130000});
      const parsed=parseFinanceUpdates(result);
      snapshot=matchFinanceUpdates(parsed.updates,records).map(row=>({
        ...row,
        kind:row.kind==='other-asset'?site.kind:row.kind,
        institution:row.institution||site.institution,
        source:`${site.label} page · ${row.confidence} confidence`
      }));
      snapshotEditing=false;renderSnapshot();
      status([snapshot.length?`${snapshot.length} account${snapshot.length===1?'':'s'} read. Nothing is saved yet.`:'No account totals were found on that page.',parsed.unread].filter(Boolean).join(' '),'snapshot-status');
    },'snapshot-status');
  }
  // Saved one at a time through the same validator and queue as a typed edit.
  // A row that fails leaves itself and the rest in place to be corrected.
  async function saveSnapshots(){
    if(!snapshot?.length)return;
    let saved=0;
    while(snapshot.length){
      if(!await saveDraft(snapshot[0],'snapshot-status')){renderSnapshot();return;}
      snapshot=snapshot.slice(1);saved++;
    }
    snapshot=null;snapshotEditing=false;renderSnapshot();onChanged();
    status(`Saved ${saved} snapshot${saved===1?'':'s'}.`,'snapshot-status');
  }

  function renderDrafts(){
    $('drafts').replaceChildren(...drafts.map((draft,index)=>DraftRow(draft,{
      onApply:()=>apply(index),
      onEdit:()=>{applyToForm(draft);drafts.splice(index,1);renderDrafts();},
      onDiscard:()=>{drafts.splice(index,1);renderDrafts();status(drafts.length?'':'Drafts discarded. Nothing was saved.','intake-status');}
    })));
  }
  // Applying a draft is an ordinary save through the same validator and queue as
  // a typed edit: nothing about an AI reading bypasses a check.
  function applyToForm(draft){
    const match=draft.match;
    if(match)fill(match);else clearForm();
    $('kind').value=match?.kind||draft.kind;
    $('name').value=match?.name||draft.name;
    if(!match){
      $('institution').value=draft.institution;
      $('owner').value=draft.owner;
      $('currency').value=draft.currency;
    }
    $('value').value=String(draft.value);
    $('asOf').value=draft.asOf;
    $('editor').open=true;
    $('value').focus();
    status('Review this draft, then save it.','form-status');
  }
  function saveDraft(draft,target='status'){
    const match=draft.ambiguous?null:draft.match;
    const id=match?.id||crypto.randomUUID();
    return run(async token=>{
      const value=normalizeFinance({
        ...(match?{}:{kind:draft.kind,name:draft.name,institution:draft.institution,owner:draft.owner,currency:draft.currency}),
        value:draft.value,asOf:draft.asOf,source:draft.source||`AI reading · ${draft.confidence} confidence`
      },match||{});
      return offline.request(token,`/v1/finance/${id}`,{method:'PUT',value:{...value,id,revision:match?.revision??null}});
    },target);
  }
  async function apply(index){
    const draft=drafts[index];
    if(await saveDraft(draft)){
      drafts.splice(index,1);renderDrafts();onChanged();
      status(`Saved ${draft.name}.`,'intake-status');
    }
  }

  // The totals and the records, built only when they have been asked for.
  function renderLedger(){
    const query=$('search').value.trim().toLowerCase();
    const visible=records.filter(record=>[record.name,record.institution,record.owner,record.tags,kindLabel(record.kind)].join(' ').toLowerCase().includes(query));
    const row=record=>{
      const shown=revealed.get(record.id);
      const remove=action('Delete',()=>{confirmation.hidden=false;yes.focus();},'danger-subtle');
      const yes=action('Delete from all devices',()=>save(record,'DELETE'),'danger');
      const no=action('Keep record',()=>{confirmation.hidden=true;remove.focus();});
      const confirmation=Stack([Note(`Permanently delete “${record.name}” and its value history from all devices?`),ActionGroup([yes,no],{compact:true})],{hidden:true});
      const history=valueHistory(record.history??'[]');
      const past=Stack(history.slice(0,8).map(entry=>Note(`${entry.asOf} · ${money(entry.value,record.currency)}${entry.source?` · ${entry.source}`:''}`)),{hidden:true});
      const actions=[
        action('Edit',()=>fill(record),'subtle'),
        ...(history.length>1?[action('History',()=>{past.hidden=!past.hidden;},'subtle')]:[]),
        ...(record.secret?[shown?action('Hide details',()=>{revealed.delete(record.id);render();}):action('Show details',()=>reveal(record)),action('Copy details',()=>copy(record),'subtle')]:[]),
        remove
      ];
      if(record.conflict)actions.push(...['local','cloud'].map(choice=>action(choice==='local'?'Keep my change':'Use cloud version',()=>resolve(record.id,choice))));
      const share=Number(record.ownership??100);
      const detail=[
        money(record.value,record.currency),
        share===100?'':`${share}% share · ${money(effectiveValue(record),record.currency)}`,
        record.asOf?`as of ${record.asOf}`:'',
        record.institution,record.owner,record.secretHint,
        record.unfunded?`${money(record.unfunded,record.currency)} unfunded`:'',
        record.pending?(record.conflict?'Conflict':record.deleting?'Pending deletion':'Waiting to sync'):''
      ].filter(Boolean).join(' · ');
      return Stack([RecordRow({title:record.name,detail,notes:record.notes,actions}),shown?MaskedValue(shown):null,past,confirmation]);
    };
    $('list').replaceChildren(...(visible.length
      ?groupFinanceRecords(visible).map(group=>FinanceGroup(group.label,group.side,group.records.map(row)))
      :[Note(!loaded?'Connect in Settings to load your records.':records.length?'No matching records.':'No records yet.')]));
    renderPosition();
  }
  // Not hidden figures: figures that were never put on the page.
  function sealLedger(){
    for(const id of ['currency-switch','totals','breakdown','trend','list'])$(id).replaceChildren();
    $('currency-switch').hidden=true;$('stale').hidden=true;
  }
  function render(){
    // What the ledger holds — the totals and the saved records — waits to be
    // asked for. Putting a figure in does not: the snapshot, the statement, the
    // page reading and a record typed by hand are all ready.
    $('position').hidden=quiet;$('records').hidden=quiet;
    if(quiet)sealLedger();else renderLedger();
    for(const key of [...core,...extra])$(key).disabled=busy||!loaded;
    for(const key of ['number','expiry'])$(`secret-${key}`).disabled=busy||!loaded;
    $('save').disabled=busy||!loaded;$('cancel').disabled=busy;
    $('read').disabled=busy||!loaded||globalThis.navigator?.onLine===false;
    $('intake').disabled=busy||!loaded;
    $('drop').disabled=busy||!loaded;
    $('page').disabled=busy||!loaded;
    // A recognized account site reads through its own panel above, which says
    // whose accounts it is about to read. Two buttons for one errand is the
    // confusion, not the second reading.
    $('page').hidden=!readPage||!!site;
    // Beside the title, only what applies: a quiet arrival can be asked for the
    // position, a loaded ledger can be refreshed, and one that never loaded
    // needs the connection rather than a dead Refresh.
    $('actions').replaceChildren(quiet?toolAction('Show position',showPosition)
      :loaded?toolAction('Refresh',refresh):toolAction('Connection settings',onSettings));
    syncSnapshot();
  }

  async function run(operation,target='status'){
    if(busy)return false;
    busy=true;const current=++generation;render();
    try{
      const token=await credentials.get();
      if(!token)throw Error('Open Settings to connect this device.');
      if(activeToken&&activeToken!==token){clear();throw Error('Connection changed. Refresh before editing.');}
      activeToken=token;
      const result=await operation(token);
      if(current!==generation)return false;
      if(result?.records){records=result.records;loaded=true;status(result.syncMessage||'');}
      return true;
    }catch(error){
      if(current!==generation)return false;
      status(vaultReason(error),target);
      return false;
    }finally{busy=false;render();}
  }
  async function save(record,method='PUT'){
    const success=await run(token=>offline.request(token,`/v1/finance/${record.id}`,{method,value:record}),'form-status');
    if(success)onChanged();
    return success;
  }
  async function resolve(id,choice){if(await run(token=>offline.resolve(token,id,choice)))onChanged();}
  async function refresh(){
    if(!gate.unlocked())return;
    status('Loading your records…');
    if(await run(token=>offline.request(token,'/v1/finance')))connectionNote();
  }
  function clear(){
    generation++;records=[];loaded=false;activeToken='';connection='';drafts=[];attachment=null;snapshot=null;snapshotEditing=false;engaged=false;forget();clearForm();renderDrafts();renderAttachment();renderSnapshot();
    status('','snapshot-status');
    status('Unlock this section with your passkey.');
    render();
  }

  // Which saved connection does the reading is not a decision worth putting in
  // front of the owner: connections are managed in Settings, and this tool
  // uses whichever one can answer. The note says only when there is none.
  const usableConnections=async token=>(await remote(token,'/v1/ai-connections')).connections.filter(entry=>entry.hasApiKey);
  async function connectionId(token){
    if(connection)return connection;
    const usable=await usableConnections(token);
    if(!usable.length)throw Error('Save an AI connection in Settings to read a statement or an account page.');
    return connection=usable[0].id;
  }
  async function connectionNote(){
    if(!activeToken||globalThis.navigator?.onLine===false){status('Offline · Add and edit records by hand; reading a statement or a page needs the internet.','ai-status');return;}
    try{
      const usable=await usableConnections(activeToken);
      connection=usable.find(entry=>entry.id===connection)?.id||usable[0]?.id||'';
      status(usable.length?'':'Save an AI connection in Settings to read a statement or an account page.','ai-status');
    }catch(error){status(error.message,'ai-status');}
  }
  async function read(){
    const text=$('intake').value.trim();
    const images=attachment?.kind==='image'?[attachment.image.dataUrl]:[];
    if(!text&&!images.length){status('Drop a statement, read the open page, or paste the figures first.','intake-status');return;}
    await run(async token=>{
      const id=await connectionId(token);
      status(images.length?'Reading the image…':'Reading…','intake-status');
      const result=await remote(token,`/v1/ai-connections/${id}/finance-intake`,{method:'POST',value:{text,...(images.length?{images}:{}),today:today()},timeoutMs:130000});
      const parsed=parseFinanceUpdates(result);
      drafts=matchFinanceUpdates(parsed.updates,records);
      renderDrafts();
      status([`${drafts.length} draft${drafts.length===1?'':'s'} ready to review. Nothing is saved until you apply one.`,parsed.unread].filter(Boolean).join(' '),'intake-status');
    },'intake-status');
  }

  $('search').addEventListener('input',render);
  $('read').addEventListener('click',read);
  $('intake-clear').addEventListener('click',()=>{$('intake').value='';drafts=[];attachment=null;renderAttachment();renderDrafts();render();status('','intake-status');status('','file-status');});
  $('page').addEventListener('click',intakeFromPage);
  attachFileDrop({zone:$('drop'),input:$('file'),status:$('file-status'),onFile:receive,accept:ACCEPTED,maxBytes:MAX_BYTES});
  $('cancel').addEventListener('click',()=>{clearForm();$('editor').open=false;});
  $('kind').addEventListener('change',()=>{
    // The kind's usual liquidity is a starting point, not a lock: it applies
    // only while the record is new and untouched.
    if(!editing)$('liquidity').value=FINANCE_KINDS.find(kind=>kind.id===$('kind').value)?.liquidity||'Liquid';
  });
  $('form').addEventListener('submit',async event=>{
    event.preventDefault();
    if(busy||!loaded)return;
    try{
      const id=editing?.id||crypto.randomUUID();
      const input=Object.fromEntries([...core,...extra].map(key=>[key,$(key).value]));
      for(const key of ['rate','commitment','unfunded'])if(input[key]==='')input[key]=null;
      const value=normalizeFinance({...input,source:'Entered by hand',...await protectedValues(id)},editing?records.find(record=>record.id===id)||{}:{});
      if(await save({...value,id,revision:editing?.revision??null})){clearForm();$('editor').open=false;}
    }catch(error){status(vaultReason(error),'form-status');}
  });
  clearForm();clear();
  if(gate.unlocked())refresh();
  const reload=()=>{if(gate.unlocked()&&!$('editor').open)refresh();};
  window.addEventListener('online',reload);
  document.addEventListener('visibilitychange',()=>{if(!document.hidden)reload();});
  credentials.subscribe?.(()=>{clear();if(gate.unlocked())refresh();});
  // One press, and the ledger is the tool it always was. Asking counts as
  // arriving at the section, so a locked vault may raise its prompt again.
  function showPosition(){
    engaged=true;
    if(!quiet)return;
    quiet=false;gate.automatic(true);
    if(loaded)render();else refresh();
  }
  // The host says how the tool was arrived at: quietly, because the tab beside
  // the panel is a finance page, or because the owner chose Finance. Choosing it
  // is the asking, so it reveals; and once revealed, a later finance page does
  // not cover the ledger up again in the same sitting.
  function arrival(hushed){
    if(!hushed){showPosition();return;}
    if(engaged||quiet)return;
    quiet=true;gate.automatic(false);render();
  }
  // The host watches the tab beside the panel and says which account site is
  // open, or passes nothing when the owner has moved on.
  function detected(next){
    if(!readPage||next?.id===site?.id)return;
    site=next||null;snapshot=null;snapshotEditing=false;
    status('','snapshot-status');renderSnapshot();render();
  }
  return {refresh,clear,site:detected,quiet:arrival,stop(){gate.stop();clearTimeout(revealTimer);}};
}
