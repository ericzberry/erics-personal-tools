import {AUTO_CAPABILITY,capabilities} from './capabilities.js';
let currentTool='football',selection=AUTO_CAPABILITY.id,settingsOpen=false;
// Anyone who wants to know which tool is on screen now: the strip under the
// header, which must not offer what the owner is already looking at.
const navigated=new Set();
export function onNavigate(listener){navigated.add(listener);return()=>navigated.delete(listener);}
const $=id=>document.getElementById(id);
function render(){
  const active=selection===AUTO_CAPABILITY.id?currentTool:selection;
  for(const key of ['football','finance','gmail','home','properties','rewards','taxes','travel','attention','subscriptions'])$(`${key}-tool`).hidden=settingsOpen||key!==active;
  $('settings-tool').hidden=!settingsOpen;
  $('current-function').textContent=settingsOpen?'Settings':selection===AUTO_CAPABILITY.id?AUTO_CAPABILITY.label:capabilities.find(item=>item.id===selection)?.label;
  $('open-settings').setAttribute('aria-expanded',String(settingsOpen));
  for(const item of capabilities){
    const node=$(`navigate-${item.id}`);
    if(!settingsOpen&&selection===item.id){node.setAttribute('aria-current','page');node.closest('.capability-submenu')?.setAttribute('open','');}
    else node.removeAttribute('aria-current');
  }
  for(const listener of navigated)listener(activeCapability());
}
// The capability actually on screen: the chosen one, or in Automatic mode
// whichever tool the tab is showing. The strip under the header reads this so
// it never offers to go where the owner already is.
export const activeCapability=()=>settingsOpen?'settings':selection===AUTO_CAPABILITY.id?currentTool:selection;
function closeNavigation(){ $('app-navigation').open=false; }
export function showTool(tool){currentTool=tool;render();}
export function showSettings(open){settingsOpen=open;closeNavigation();render();}
export function selectCapability(id){selection=id;settingsOpen=false;closeNavigation();render();$('navigation-toggle').focus();}
export function showRewards(open){selectCapability(open?'rewards':AUTO_CAPABILITY.id);}
export function initializeNavigation(){
  for(const item of capabilities)if(!item.href)$(`navigate-${item.id}`).addEventListener('click',()=>selectCapability(item.id));
  document.addEventListener('pointerdown',event=>{if(!$('app-navigation').contains(event.target))closeNavigation();});
  render();
}

export function selectTool(tool){selectCapability(tool||AUTO_CAPABILITY.id);}
