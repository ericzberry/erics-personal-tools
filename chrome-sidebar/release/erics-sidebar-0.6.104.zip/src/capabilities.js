// Shared data destinations used by desktop and mobile.
// Every entry in both lists needs an `icon`: a 24x24 stroked SVG path drawn with
// currentColor. The mobile launcher and the sidebar Tools menu both render one
// per entry, so a capability without an icon is incomplete in either host.
// `section` groups an entry under a named group in both hosts; entries without
// one stay in the main, unlabelled group. A named section needs an icon here
// because the sidebar presents it as a menu row that opens to reveal its tools.
export const MISC_SECTION='Misc';
const SECTION_ICONS=new Map([[MISC_SECTION,'M6 12h.01 M12 12h.01 M18 12h.01']]);
export const CAPABILITIES = [
  {id:'travel',label:'Travel wallet',href:'travel.html',icon:'M3 8h18v11a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V8Z M9 8V5h6v3'},
  {id:'attention',label:'Needs attention',href:'attention.html',icon:'M9 4h6l6 16H3L9 4Z M12 9v5 M12 17h.01'},
  {id:'subscriptions',label:'Subscriptions & renewals',href:'subscriptions.html',icon:'M4 8a8 8 0 0 1 14-2l2 2 M20 3v5h-5 M20 16a8 8 0 0 1-14 2l-2-2 M4 21v-5h5'},
  {id:'gifts',label:'Gift ideas',href:'gifts.html',icon:'M3 11h18v9a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1v-9Z M2.5 7.5h19V11h-19V7.5Z M12 7.5V21 M12 7.5C10.6 5 9.2 3.6 8 4.3c-1.2.8-.4 3.2 4 3.2Z M12 7.5c1.4-2.5 2.8-3.9 4-3.2 1.2.8.4 3.2-4 3.2Z'},
  {id:'reminders',label:'Reminders',href:'reminders.html',icon:'M12 4a5 5 0 0 0-5 5v3.4L5.5 16h13L17 12.4V9a5 5 0 0 0-5-5Z M10 19a2 2 0 0 0 4 0'},
  {id:'rewards',label:'Rewards & benefits',href:'rewards.html',icon:'M12 4l2.4 4.9 5.4.8-3.9 3.8.9 5.3-4.8-2.5-4.8 2.5.9-5.3L4.2 9.7l5.4-.8L12 4Z'},
  {id:'cards',label:'Best card',href:'cards.html',icon:'M3 7a1 1 0 0 1 1-1h16a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V7Z M3 10.5h18'},
  {id:'finance',label:'Finance',href:'finance.html',icon:'M4 20V10 M9.5 20V5 M15 20v-7 M20.5 20V8 M3 20h18'},
  {id:'properties',label:'Properties',href:'properties.html',icon:'M3.5 11 12 4l8.5 7 M5.5 9.5V20h13V9.5 M10 20v-5.5h4V20'},
  {id:'personal',label:'Personal information',href:'personal.html',icon:'M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8Z M5 20a7 7 0 0 1 14 0'},
  {id:'taxes',label:'Taxes',href:'taxes.html',icon:'M6 3h7l5 5v13a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1Z M13 3v5h5 M9 13h6 M9 17h4'},
  {id:'rankings',label:'Player rankings',href:'data.html?capability=rankings',section:MISC_SECTION,icon:'M5 20v-6 M12 20V5 M19 20v-9'},
  {id:'restaurants',label:'Restaurants',href:'restaurants.html',icon:'M7 3v6a2 2 0 0 0 4 0V3 M9 3v4 M9 9v12 M17 21V3l3 4.5-3 4.5'}
];
// Alphabetical by label, for hosts that present tools as a flat list.
export const capabilitiesByName=[...CAPABILITIES].sort((a,b)=>a.label.localeCompare(b.label));
export const DEFAULT_CAPABILITY=CAPABILITIES[0].id;
// Groups entries for presentation: the unlabelled group first, then each named
// section in registry order. Both hosts render the same grouping.
export function capabilitySections(items=CAPABILITIES){
  const groups=new Map([[null,[]]]);
  for(const item of items){
    const title=item.section??null;
    if(!groups.has(title))groups.set(title,[]);
    groups.get(title).push(item);
  }
  return [...groups].filter(([,list])=>list.length).map(([title,list])=>({title,icon:title?SECTION_ICONS.get(title):null,items:list}));
}
// Gmail is not listed: it appears on its own when the active tab is Gmail.
// Automatic mode has no menu row: it is the state the sidebar starts in, and
// the toggle names it, so listing it again would be a row for "no tool chosen".
export const AUTO_CAPABILITY={id:'auto',label:'Current tab'};
export const capabilities=[
  ...CAPABILITIES.map(({href,...rest})=>['travel','rewards','finance','taxes','properties','attention','subscriptions'].includes(rest.id)?rest:{...rest,href}),
  {id:'football',label:'Fantasy football',section:MISC_SECTION,icon:'M7.5 4h9v5a4.5 4.5 0 0 1-9 0V4Z M12 13.5V17 M8.5 20h7'}
];
