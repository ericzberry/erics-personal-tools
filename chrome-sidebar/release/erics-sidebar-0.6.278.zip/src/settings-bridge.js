import {disconnectPrivateData} from './private-disconnect.js';
import {releaseChecker} from './release-check.js';
const releaseChecks=new WeakMap();
import {migrateCredentials} from './credential-migration.js';
import {cloudRequest, CONNECTION_KEY} from './cloud-storage.js';
export function isSettingsPage(sender, chromeApi) {
  return sender?.id === chromeApi.runtime.id && ['settings.html','sidepanel.html','restaurants.html'].some(path=>sender.url === chromeApi.runtime.getURL(path));
}
export async function settingsAction(message, chromeApi, request = cloudRequest) {
  const storage = chromeApi.storage.local;
  await storage.setAccessLevel({accessLevel:'TRUSTED_CONTEXTS'});
  if(message.action==='release-check'){
    if(!releaseChecks.has(storage))releaseChecks.set(storage,releaseChecker(storage));
    return releaseChecks.get(storage)();
  }
  if (message.action === 'disconnect') {
    const token=(await storage.get(CONNECTION_KEY))[CONNECTION_KEY]?.token;
    await disconnectPrivateData(token);
    await storage.remove(CONNECTION_KEY); return {connected:false};
  }
  const saved = (await storage.get(CONNECTION_KEY))[CONNECTION_KEY];
  const token = saved?.token || '';
  if (message.action === 'status') return {connected:!!token};
  if (message.action === 'connect') {
    const next = typeof message.token === 'string' ? message.token.trim() : token;
    const health = await request(next, '/health');
    if (!health.ok || health.service !== 'erics-tools-api' || health.version !== 2) throw Error('Update the cloud settings service before connecting.');
    await request(next, '/v1/ai-connections');
    if(token&&token!==next)await disconnectPrivateData(token);
    await storage.set({[CONNECTION_KEY]:{token:next}});
    return {connected:true};
  }
  if (message.action === 'migrate') return migrateCredentials(storage,token,request);
  if(message.action==='rewards-list')return request(token,'/v1/rewards');
  if(message.action==='rewards-save')return request(token,'/v1/rewards',{method:'PUT',value:{entries:message.entries,revision:message.revision}});
  // The writing voice: what was learned, the study that learns it one page of
  // sent mail at a time, the owner's own corrections, and forgetting it. The
  // scan is given a long timeout because one call reads a page of Gmail and may
  // then read that batch with the model.
  if(message.action==='voice')return request(token,'/v1/voice');
  if(message.action==='voice-scan')return request(token,'/v1/voice/scan',{method:'POST',value:{connectionId:message.connectionId,restart:!!message.restart},timeoutMs:180000});
  if(message.action==='voice-save')return request(token,'/v1/voice',{method:'PUT',value:{prompt:message.prompt}});
  if(message.action==='voice-forget')return request(token,'/v1/voice',{method:'DELETE'});
  // The same Google account the tax filing uses, consented again so it also
  // covers reading sent mail.
  if(message.action==='google-connect')return request(token,'/v1/drive/connect',{method:'POST',value:{}});
  // How much of Cloudflare's storage the account has used. The Worker keeps the
  // last reading; `refresh` is the owner asking for it now rather than hourly.
  if(message.action==='storage')return request(token,`/v1/storage${message.refresh?'?refresh=1':''}`);
  // Which model runs which action. The only place in the app a model is named.
  if (message.action === 'ai-tasks') return request(token, '/v1/ai-tasks');
  if (message.action === 'ai-task-save') return request(token, `/v1/ai-tasks/${encodeURIComponent(message.task)}`, {method:'PUT', value:{model:message.model}});
  if (message.action === 'list') return request(token, '/v1/ai-connections');
  if (!['save', 'remove','models','test','generate','restaurants'].includes(message.action) || !/^[a-f0-9-]{36}$/.test(message.id || '')) throw Error('Unknown settings action.');
  // Research reads the web and then the sources it cites, so it is given the
  // Worker's own two minutes plus the source reads.
  if(message.action==='restaurants')return request(token,`/v1/ai-connections/${message.id}/restaurants`,{method:'POST',value:{model:message.model,search:message.search,intent:message.intent},timeoutMs:150000});
  if(message.action==='models')return request(token,`/v1/ai-connections/${message.id}/models`);
  if(message.action==='test')return request(token,`/v1/ai-connections/${message.id}/test`,{method:'POST',value:{model:message.model}});
  if(message.action==='generate')return request(token,`/v1/ai-connections/${message.id}/generate`,{method:'POST',value:{task:message.task,model:message.model,messages:message.messages,maxTokens:message.maxTokens}});
  if (message.action === 'remove') return request(token, `/v1/ai-connections/${message.id}`, {method:'DELETE', value:{revision:message.revision}});
  const data = message.connection;
  if (!data || typeof data !== 'object') throw Error('Connection settings are required.');
  // Never allow callers to turn this into a general network or storage proxy.
  const value = {name:data.name, provider:data.provider, baseUrl:data.baseUrl, apiFormat:data.apiFormat, revision:data.revision};
  if (typeof data.apiKey === 'string') value.apiKey = data.apiKey;
  return request(token, `/v1/ai-connections/${message.id}`, {method:'PUT', value});
}
export function registerSettingsBridge(chromeApi) {
  chromeApi.runtime.onMessage.addListener((message, sender, respond) => {
    if (message?.type !== 'ERIC_SETTINGS') return;
    if (!isSettingsPage(sender, chromeApi)) {respond({ok:false, error:'Settings page access required.'}); return;}
    settingsAction(message, chromeApi).then(value => respond({ok:true, ...value})).catch(error => respond({ok:false, error:error.name === 'TimeoutError' ? 'The connection timed out. Try again.' : error.message}));
    return true;
  });
  chromeApi.omnibox.setDefaultSuggestion({description:'Open Eric’s personal settings'});
  chromeApi.omnibox.onInputEntered.addListener((_text, disposition) => {
    const url = chromeApi.runtime.getURL('settings.html');
    if (disposition === 'currentTab') chromeApi.tabs.update({url});
    else chromeApi.tabs.create({url, active:disposition !== 'newBackgroundTab'});
  });
}
