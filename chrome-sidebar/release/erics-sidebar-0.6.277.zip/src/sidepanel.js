import {rosterCounts,currentTierPlayers,pickCountdown} from './draft-presentation.js';
import {fetchEspnCatalog, reconcileRankings, reconcileSession, correctionPlayers} from './espn-catalog.js';
import {createManualDraft, applyManualDraft, setManualPick, setManualProgress, resetManualDraft} from './manual-draft.js';
import {playerKey} from './player-identity.js';
import {downloadFile, RosterCounts, TieredRankings, SelectionRow, setStatus} from './components/ui.js';
import {selectSession} from './session-selection.js';
import {sessionKey} from './draft-state.js';
import {recommend} from './recommendations.js';
const $ = id => document.getElementById(id);
const extension = !!globalThis.chrome?.storage?.local;
let config, rankings, sourceRankings, catalog, catalogPlayers=[], syncMessage='', syncing=false, sessions = {}, selected = 'auto', manualDrafts = {};
let manualWrites=Promise.resolve();
let lastBoardSignature, lastTierSession, highlightedTab, lastRosterSignature;
let recommendedKeys=[];
let rosterAlerts=[];
const tierStates=new Map();
const liveSession=()=>reconcileSession(selectSession(sessions,selected),catalog);
const currentKey=()=>liveSession()?sessionKey(liveSession()):(selected==='auto'?'league:2026:182527585':selected);
const effectiveSession=()=>reconcileSession(applyManualDraft(liveSession(),manualDrafts[currentKey()]),catalog);
function renderDraft() {
  const s=effectiveSession();const live=s?.connected && Date.now()-s.lastSeenAt<15000;
  const warning=s?.missing?.length?`${s.missing.length} earlier pick(s) missing. Open ESPN’s Pick History or reload the draft room to recover available history.`:s?.rejected?'Some ESPN pick entries could not be read. Check ESPN’s pick history.':'';
  $('coverage').hidden=!warning;$('coverage').textContent=warning;
  renderAdvice(s);
  const counts=rosterCounts(s),countSignature=JSON.stringify([counts,!!s,rosterAlerts]);
  if(countSignature!==lastRosterSignature){lastRosterSignature=countSignature;$('roster-counts').replaceChildren(RosterCounts(counts,{known:!!s,alerts:rosterAlerts}));}
  const confirmed=!!s&&(s.manualMode||(live&&!s.missing?.length&&!s.rejected&&!s.identityIssues));
  const key=currentKey();if(key!==lastTierSession){tierStates.clear();lastTierSession=key;}
  const boardSignature=JSON.stringify([key,rankings?.players,s?.picks,s?.teamId,confirmed,recommendedKeys,rosterAlerts,!!manualDrafts[key]?.active,manualDrafts[key]?.overrides]);
  if(boardSignature!==lastBoardSignature&&rankings){lastBoardSignature=boardSignature;$('spreadsheet-players').replaceChildren(...TieredRankings(rankings.players.map(p=>({...p,key:playerKey(p)})),new Map((s?.picks||[]).map(p=>[playerKey(p),p])),s?.teamId,{confirmed,recommended:recommendedKeys,rosterAlerts,overrides:manualDrafts[key]?.overrides,tierStates,onSelect:manualDrafts[key]?.active?markPlayer:null}));}
  renderManual();
}
function renderAdvice(session) {
  if (!rankings) return;
  const advice = recommend({rankings, config, session});
  const countdown=pickCountdown(session,advice.turn,{blocked:!!advice.blocked});
  $('advice-context').textContent = session ? `${session.manualMode?'Manual board':`Through #${advice.throughPick}`}${advice.turn.nextPick ? ` · Next #${advice.turn.nextPick}` : ' · Your turn unknown'}${countdown?` · ${countdown}`:''}${advice.turn.followingPick ? ` · Then #${advice.turn.followingPick}` : ''}` : '';
  setStatus($('advice-status'), !session ? 'Connect a draft to see your next pick.' : advice.blocked || '', session ? 'alert' : '');
  $('advice-status').hidden = !$('advice-status').textContent;
  const candidates=session?advice.candidates:[];
  recommendedKeys=candidates.map(playerKey);
  rosterAlerts=advice.rosterAlerts;
  sendHighlights(session,candidates,session&&!advice.blocked?currentTierPlayers(rankings.players,session):[],rankings.players.filter(p=>rosterAlerts.some(a=>a.playerKeys.includes(playerKey(p)))));

}

async function sendHighlights(session,candidates,tierPlayers,scarcityPlayers){
  if(!globalThis.chrome?.tabs?.sendMessage)return;
  const tab=session?.tabId;
  if(highlightedTab!==undefined&&highlightedTab!==tab)chrome.tabs.sendMessage(highlightedTab,{type:'DRAFT_RECOMMENDATIONS',clear:true}).catch(()=>{});
  highlightedTab=tab;
  if(tab===undefined)return;
  const player=p=>({espnId:p.espnId,name:p.name,position:p.position,nflTeam:p.nflTeam,tier:p.tier});
  try {await chrome.tabs.sendMessage(tab,{type:'DRAFT_RECOMMENDATIONS',leagueId:session.leagueId,seasonId:session.seasonId,teamId:session.teamId,onClock:session.onClock,manualMode:!!session.manualMode,tierPlayers:tierPlayers.map(player),scarcityPlayers:scarcityPlayers.map(player),candidates:candidates.map(player),expiresAt:Date.now()+12000});
  }catch { /* Retry on the next draft update; highlights expire automatically. */ }

}

function renderManual(updateFields=false) {
  if(!rankings)return;
  const record=manualDrafts[currentKey()],s=effectiveSession();
  $('capture-picks').checked=!record?.active;
  $('manual-settings').hidden=!record?.active;
  if(updateFields){$('manual-clock').value=record?.onClock??s?.onClock??'';$('manual-slot').value=record?.slot??'';}
  const taken=new Map((s?.picks||[]).map(p=>[playerKey(p),p]));
  const query=$('manual-search').value.toLowerCase().trim();
  const matches=query&&record?.active?catalogPlayers.filter(p=>!p.rank&&`${p.name} ${p.spreadsheetName||''} ${p.position} ${p.nflTeam} ${p.espnId}`.toLowerCase().includes(query)):[];
  const players=matches.slice(0,40);
  $('manual-result-count').textContent=query&&record?.active?(matches.length?`Showing ${players.length} of ${matches.length}`:'No players outside your spreadsheet match.'):'';
  setStatus($('espn-sync-status'),syncMessage||`${catalog.players.length.toLocaleString()} ESPN entries · ${rankings.players.filter(p=>!p.identityUnverified).length}/${rankings.players.length} ranks matched · ${new Date(catalog.fetchedAt).toLocaleDateString()}`,syncMessage?(syncing?'progress':'error'):'');
  $('manual-players').replaceChildren(...players.map(p=>{
    const pick=taken.get(playerKey(p)),owner=pick?(pick.teamId===s.teamId?'me':'other'):null;
    return SelectionRow(p,{owner,corrected:!!record?.overrides[playerKey(p)],onSelect:value=>changeManual(r=>setManualPick(r,p,value),`${p.name}: ${value==='undo'?'correction undone':value==='me'?'taken by you':'taken by someone else'}.`)});
  }));
}
function changeManual(update,message='Saved.',feedbackId='manual-feedback') {
  const key=currentKey(),source=liveSession();selected=key;
  manualWrites=manualWrites.catch(()=>{}).then(async()=>{
    try {
      const saved=extension?await chrome.storage.local.get('manualDrafts'):{};
      const all=saved.manualDrafts||manualDrafts;
      const updated={...all,[key]:update(all[key]||createManualDraft(source,config))};
      if(extension)await chrome.storage.local.set({manualDrafts:updated});manualDrafts=updated;if(!updated[key].active)selected='auto';
      $(feedbackId).hidden=false;$(feedbackId).textContent=message;
      renderDraft();renderManual(true);return true;
    }catch(error){$(feedbackId).hidden=false;$(feedbackId).textContent=error.message;return false;}
  });
  return manualWrites;
}
function markPlayer(player,value){if(!manualDrafts[currentKey()]?.active)return;return changeManual(r=>setManualPick(r,player,value),`${player.name}: ${value==='undo'?'correction undone':value==='me'?'taken by you':'taken by someone else'}.`);}
$('reset-draft').addEventListener('click',async()=>{
  $('reset-draft').disabled=true;
  try {
    const reset=await changeManual(resetManualDraft,'Draft reset. Live capture is off; start marking picks or resume capture in Settings.','reset-draft-status');
    if(reset){
      tierStates.clear();lastBoardSignature=null;
      $('manual-search').value='';$('manual-feedback').hidden=true;
      renderDraft();renderManual(true);
    }
  }finally{$('reset-draft').disabled=false;}
});
$('download-espn-diagnostics').addEventListener('click',async()=>{
  try{
    const tab=liveSession()?.tabId;if(tab===undefined)throw Error('Open the ESPN draft first.');
    const result=await chrome.tabs.sendMessage(tab,{type:'ESPN_HIGHLIGHT_DIAGNOSTICS'});
    if(!result)throw Error('Reload the extension and ESPN, then try again.');
    const url=URL.createObjectURL(new Blob([JSON.stringify({sidebarVersion:chrome.runtime.getManifest().version,...result},null,2)],{type:'application/json'}));
    downloadFile({url,filename:'espn-highlight-diagnostics.json'});setTimeout(()=>URL.revokeObjectURL(url),10000);
  }catch(error){setStatus($('espn-sync-status'),error.message,'error');}
});
$('draft-settings').addEventListener('toggle',()=>{if($('draft-settings').open)renderManual(true);});
$('capture-picks').addEventListener('change',async()=>{
  const active=!$('capture-picks').checked;$('capture-picks').disabled=true;
  try{await changeManual(r=>({...r,active}));}
  finally{$('capture-picks').disabled=false;renderManual();}
});
function useCatalog(next){catalog=next;rankings=reconcileRankings(sourceRankings,catalog);catalogPlayers=correctionPlayers(rankings,catalog);}
$('sync-espn-players').addEventListener('click',async()=>{
  $('sync-espn-players').disabled=true;syncing=true;syncMessage='Syncing ESPN players…';renderManual();
  try{const next=await fetchEspnCatalog(config.seasonId);if(extension)await chrome.storage.local.set({espnCatalog:next});useCatalog(next);syncMessage='';renderDraft();}
  catch(error){syncMessage=error.message;}
  finally{syncing=false;$('sync-espn-players').disabled=false;renderManual();}
});
$('manual-search').addEventListener('input',()=>renderManual());
$('save-manual-progress').addEventListener('click',()=>{
  const clock=$('manual-clock').value.trim(),slot=$('manual-slot').value;
  changeManual(r=>setManualProgress(r,clock?Number(clock):null,slot?Number(slot):null),'Draft progress saved.');
});
try {
  const response=await fetch('./config/espn-league-2026.json');if(!response.ok)throw Error('League settings could not be loaded.');config=await response.json();
  const ranksResponse=await fetch('./config/rankings-2026.json');if(!ranksResponse.ok)throw Error('Rankings could not be loaded.');sourceRankings=await ranksResponse.json();
  const catalogResponse=await fetch('./config/espn-players-2026.json');if(!catalogResponse.ok)throw Error('ESPN player list could not be loaded.');useCatalog(await catalogResponse.json());
  if(extension){
    const saved=await chrome.storage.local.get(['draftSessions','manualDrafts','espnCatalog']);sessions=saved.draftSessions || {};manualDrafts=saved.manualDrafts || {};const activeKey=liveSession()?sessionKey(liveSession()):'league:2026:182527585';if(manualDrafts[activeKey]?.active)selected=activeKey;if(saved.espnCatalog?.seasonId===config.seasonId&&saved.espnCatalog.fetchedAt>catalog.fetchedAt)useCatalog(saved.espnCatalog);
    chrome.storage.onChanged.addListener((changes,area)=>{
      if(area!=='local')return;
      if(changes.espnCatalog?.newValue?.seasonId===config.seasonId)useCatalog(changes.espnCatalog.newValue);
      if(changes.draftSessions)sessions=changes.draftSessions.newValue || {};
      if(changes.manualDrafts)manualDrafts=changes.manualDrafts.newValue || {};
      renderDraft();
    });
  }
  renderDraft();setInterval(renderDraft,5000);
} catch(error){$('error').hidden=false;$('error').textContent=error.message;}
