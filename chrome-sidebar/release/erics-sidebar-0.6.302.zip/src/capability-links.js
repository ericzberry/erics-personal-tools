import {mountExtensionTravel} from './travel-page.js';
let mounted=false,travelTool=null;
// Settings shows the wallet's connection panel, so Settings mounts it too.
export function mountTravelTool(){
  const root=document.getElementById('travel-tool');
  if(root&&!mounted){travelTool=mountExtensionTravel(root,{mode:'inline'});mounted=true;}
  return travelTool;
}
document.getElementById('navigate-travel')?.addEventListener('click',mountTravelTool);

// Finance opens in the sidebar, beside the account page it reads. The tool is
// built on first use so a sidebar that never opens it pays nothing for it.
//
// How it was arrived at is the tool's to know: choosing Finance is the owner
// asking for their position, while the panel turning to it beside a finance page
// is not, and opens it quiet.
let finance=null;
export function openFinanceTool({quiet=false}={}){
  const root=document.getElementById('finance-tool');
  if(!root)return null;
  finance??=(async()=>{
    const [{mountExtensionFinance,openFinanceDetails},{readOpenAccountPage}]=await Promise.all([import('./finance-page.js'),import('./finance-page-read.js')]);
    // The panel keeps what it all comes to and the ways a figure gets in; the
    // ledger itself, entity by entity, is read on its own page.
    return mountExtensionFinance(root,{quiet,layout:'panel',openDetails:()=>openFinanceDetails(),
      readPage:()=>readOpenAccountPage(),onSettings:()=>document.getElementById('open-settings')?.click()});
  })();
  finance.then(tool=>tool.quiet(quiet)).catch(()=>{/* A tool that will not mount reports itself through its own caller. */});
  return finance;
}
// Whoever is already mounted, without building the tool to ask. A tab that has
// stopped being a finance page has nothing to tell a panel that never opened
// Finance, and building one to hear it would be the sidebar arriving at a
// protected section on its own account.
export const mountedFinanceTool=()=>finance;
document.getElementById('navigate-finance')?.addEventListener('click',()=>openFinanceTool());

// Taxes opens in the panel beside the mail a document arrives in, so a K-1 can
// go from the message straight into the drop zone without a tab in between —
// and a filed one can go back out onto the page beside it the same way.
let taxes=null;
export function openTaxesTool(){
  const root=document.getElementById('taxes-tool');
  if(!root)return null;
  taxes??=import('./taxes-page.js').then(({mountExtensionTaxes})=>
    mountExtensionTaxes(root,{beside:true,onSettings:()=>document.getElementById('open-settings')?.click()}));
  return taxes;
}
document.getElementById('navigate-taxes')?.addEventListener('click',openTaxesTool);

// A panel tool reached from anywhere other than its own menu row — the strip
// under the header — has to be built the same way its row would build it.
let attention=null,subscriptions=null;
export function openSubscriptionsTool(){
  const root=document.getElementById('subscriptions-tool');
  if(!root)return null;
  subscriptions??=import('./subscriptions-page.js').then(({mountExtensionSubscriptions})=>mountExtensionSubscriptions(root,{onSettings:()=>document.getElementById('open-settings')?.click()}));
  return subscriptions;
}
export function openAttentionTool(){
  const root=document.getElementById('attention-tool');
  if(!root)return null;
  attention??=import('./attention-page.js').then(({mountExtensionAttention})=>mountExtensionAttention(root,{automatic:false,onSettings:()=>document.getElementById('open-settings')?.click(),onOpen:async(id,recordId,destination=id)=>{
    // Everything attention can point at lives in the panel, so going there is
    // selecting it here rather than opening a tab beside the page it is about.
    const item=CAPABILITIES.find(c=>c.id===id);
    if(PANEL_TOOLS[id]||item&&!item.href){
      const {selectCapability}=await import('./navigation.js');selectCapability(destination);const tool=await openPanelTool(id);if(id==='travel')tool?.setScope(destination==='documents'?'documents':'memberships');
    }else if(globalThis.chrome?.tabs?.create)chrome.tabs.create({url:chrome.runtime.getURL(item.href)});
    else location.assign(item.href);
  }}));
  attention.then(tool=>tool.refresh());
  return attention;
}
document.getElementById('navigate-attention')?.addEventListener('click',openAttentionTool);
document.getElementById('navigate-subscriptions')?.addEventListener('click',openSubscriptionsTool);
// The rest of the panel tools, each built on first use and each mounted into
// the section the panel already holds for it. One shape, because the only thing
// that differs between them is which module does the mounting.
const settings=()=>document.getElementById('open-settings')?.click();
const panelTool=(id,load)=>{
  let tool=null;
  const open=()=>{
    const root=document.getElementById(`${id}-tool`);
    if(!root)return null;
    tool??=load(root,{onSettings:settings});
    return tool;
  };
  document.getElementById(`navigate-${id}`)?.addEventListener('click',open);
  return open;
};
export const openPeopleTool=panelTool('people',(root,options)=>import('./people-page.js').then(({mountExtensionPeople})=>mountExtensionPeople(root,options)));
export const openTripsTool=panelTool('trips',(root,options)=>import('./trips-page.js').then(({mountExtensionTrips})=>mountExtensionTrips(root,options)));
export const openGiftsTool=panelTool('gifts',(root,options)=>import('./gifts-page.js').then(({mountExtensionGifts})=>mountExtensionGifts(root,options)));
export const openSizesTool=panelTool('sizes',(root,options)=>import('./sizes-page.js').then(({mountExtensionSizes})=>mountExtensionSizes(root,options)));
export const openReplacementsTool=panelTool('replacements',(root,options)=>import('./replacements-page.js').then(({mountExtensionReplacements})=>mountExtensionReplacements(root,options)));
export const openRemindersTool=panelTool('reminders',(root,options)=>import('./reminders-page.js').then(({mountExtensionReminders})=>mountExtensionReminders(root,options)));
export const openCardsTool=panelTool('cards',(root,options)=>import('./cards-page.js').then(({mountExtensionCards})=>mountExtensionCards(root,options)));
export const openAdvisorTool=panelTool('advisor',(root,options)=>import('./advisor-page.js').then(({mountExtensionAdvisor})=>mountExtensionAdvisor(root,options)));
export const openPersonalTool=panelTool('personal',(root,options)=>import('./personal-page.js').then(({mountExtensionPersonal})=>mountExtensionPersonal(root,options)));
export const openHealthTool=panelTool('health',(root,options)=>import('./health-page.js').then(({mountExtensionHealth})=>mountExtensionHealth(root,options)));

const PANEL_TOOLS={people:openPeopleTool,trips:openTripsTool,attention:openAttentionTool,subscriptions:openSubscriptionsTool,travel:mountTravelTool,finance:openFinanceTool,taxes:openTaxesTool,
  gifts:openGiftsTool,sizes:openSizesTool,replacements:openReplacementsTool,reminders:openRemindersTool,cards:openCardsTool,advisor:openAdvisorTool,personal:openPersonalTool,health:openHealthTool};
// A tool opened again reads its records again, so no tool needs a Refresh
// button to show what changed on another device (UI-64). The first opening is
// the mount, which reads them already; an editor with unsaved work is left as
// it is. Today's attention list is mounted with the home screen, not by it.
const opened=new Set();
export function openPanelTool(id){
  if(id==='home'){attention?.then(tool=>tool?.refresh?.());return null;}
  const tool=PANEL_TOOLS[id]?.()??null;
  if(tool&&opened.has(id))Promise.resolve(tool).then(t=>{if(!t?.isDirty?.())t?.refresh?.({quiet:true});});
  if(tool)opened.add(id);
  return tool;
}

// Standalone settings/data pages use the same data registry in the shared formatted picker.
const {CAPABILITIES,APP_AREAS}=await import('./capabilities.js');
const picker=document.getElementById('capability-picker');
picker?.addEventListener('change',()=>{
  const area=APP_AREAS.find(a=>`area-${a.id}`===picker.value);
  const capability=area?{href:`sidepanel.html?area=${area.id}`}:CAPABILITIES.find(c=>c.id===picker.value);
  if(capability){
    if(globalThis.chrome?.tabs?.create&&location.protocol==='chrome-extension:')chrome.tabs.create({url:chrome.runtime.getURL(capability.href)});
    else location.assign(capability.href);
  }
  picker.value='';
});
