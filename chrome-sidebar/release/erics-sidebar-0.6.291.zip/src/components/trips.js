import {Stack,Section,Heading,Text,Note,Strong,Link,Button,ActionGroup,Disclosure,Form,FormField,Notice,ToolTitle,RowAction,EDIT_GLYPH,DELETE_GLYPH,ResultBlock,money} from './ui.js';
import {rankCandidates,researchCurrent,offerState,tripKey,TRIP_RETENTION_MS,tripSources,tripCoverage} from '../trip-data.js';
const when=value=>value?new Date(value).toLocaleString(undefined,{dateStyle:'medium',timeStyle:'short'}):'';
export function TripsView(){
  return Stack([
    ToolTitle('Travel planning',{actionsId:'trips-actions',statusId:'trips-status'}),
    Stack([],{id:'trips-picker'}),
    Stack([],{id:'trips-result'}),
    Disclosure('Trip request',[
      Form([
        FormField({id:'trips-title',label:'Trip name',kind:'text',required:true,maxLength:120}),
        FormField({id:'trips-kind',label:'Travel',kind:'select',options:[{value:'hotel',text:'Hotel'},{value:'flight',text:'Flights'},{value:'both',text:'Hotel and flights'}]}),
        FormField({id:'trips-request',label:'What you want',kind:'textarea',required:true,maxLength:4000,rows:4}),
        Notice('',{id:'trips-form-status'}),
        ActionGroup([Button('Save trip',{id:'trips-save',variant:'primary',type:'submit'}),Button('Cancel',{id:'trips-cancel',variant:'secondary'})])
      ],{id:'trips-form',className:'form-stack'})
    ],{id:'trips-editor'})
  ],{className:'travel-wallet trip-workspace'});
}
export const TripPicker=(records,selected,onSelect)=>{
  const field=FormField({id:'trips-selected',label:'Saved trips',kind:'select',options:records.map(t=>({value:t.id,text:t.title}))});
  const select=field.querySelector('select');select.value=selected;select.dispatchEvent(new document.defaultView.Event('change'));
  select.addEventListener('change',()=>onSelect(select.value));return field;
};
const fitLabel={match:'Requirements supported',unknown:'Needs verification',mismatch:'Does not meet requirements'};
const checkLabel={match:'Supported',mismatch:'Does not match',unknown:'Not verified'};
const checkRows=(trip,checks)=>trip.criteria.map(c=>{
  const check=checks.find(x=>x.id===c.id);
  return Stack([Strong(c.label),Text(`${checkLabel[check?.status||'unknown']}${c.required?'':' · preference'}${check?.detail?` — ${check.detail}`:''}`),
    check?.source?Link(`Source · ${when(check.checkedAt)}`,check.source):null],{className:'trip-check'});
});
export function TripComparison(trip,{onEdit,onDelete,onCopy,onResolve,onResearch,onOpenResults,onStop,onSource=()=>{},source='web',researching=false,busy=false,now=Date.now()}){
  const actions=[RowAction(EDIT_GLYPH,`Edit ${trip.title}`,onEdit,{disabled:busy}),RowAction(DELETE_GLYPH,`Delete ${trip.title}`,()=>{confirm.hidden=false;},{disabled:busy,danger:true})];
  const yes=Button('Delete trip from all devices',{variant:'danger',disabled:busy});yes.addEventListener('click',onDelete);
  const no=Button('Keep trip',{variant:'secondary'});no.addEventListener('click',()=>{confirm.hidden=true;});
  const confirm=Stack([Text(`Delete “${trip.title}” and its saved research?`),ActionGroup([yes,no])],{hidden:true});
  const copy=Button('Copy research request',{variant:'secondary',size:'compact',disabled:busy});copy.addEventListener('click',onCopy);
  const current=researchCurrent(trip);
  let search=null;
  if(onResearch){
    const sources=tripSources(trip),selected=sources.some(c=>c.id===source)?source:sources[0].id;
    const field=FormField({id:'trips-source',label:'Source',kind:'select',options:sources.map(c=>({value:c.id,text:c.label}))});
    const select=field.querySelector('select');select.value=selected;select.disabled=busy||researching;select.dispatchEvent(new document.defaultView.Event('change'));
    select.addEventListener('change',()=>onSource(select.value));
    const all=Button('Search all sources',{variant:'primary',size:'compact',disabled:busy||researching});all.addEventListener('click',()=>onResearch('all'));
    const run=Button('Search source',{variant:'secondary',size:'compact',disabled:busy||researching});run.addEventListener('click',()=>onResearch(select.value));
    const stop=Button('Stop search',{variant:'secondary',size:'compact'});stop.addEventListener('click',onStop);
    search=Stack([ActionGroup([all,...(researching?[stop]:[])]),Disclosure('Search one source',[field,ActionGroup([run])])]);
  }
  const open=onOpenResults?Button('Open results page',{variant:'secondary',size:'compact'}):null;open?.addEventListener('click',onOpenResults);
  const auth=trip.channels.filter(c=>c.status==='login');
  const summary=Stack([
    Stack([Heading(trip.title,2),ActionGroup(actions,{compact:true})],{className:'trip-heading group-line'}),confirm,
    auth.length?Section([Heading('Sign-in needs your help',3),...auth.map(c=>Stack([Notice(`${c.label}: ${c.nextStep||c.note||'Complete sign-in, then resume research.'}`,{tone:'alert'}),c.resumeURL?Link('Open sign-in',c.resumeURL):null],{className:'trip-check'}))],{className:'trip-auth'}):null,
    Text(trip.request),
    trip.updatedAt?Note(`Research expires ${new Date(Date.parse(trip.updatedAt)+TRIP_RETENTION_MS).toLocaleDateString()}`):null,
    trip.start?Note(`${trip.start}${trip.end?` → ${trip.end}`:''}${trip.party?` · ${trip.party.adults} adults${trip.party.childrenAges.length?`, children aged ${trip.party.childrenAges.join(', ')}`:''} · ${trip.party.rooms} room(s)`:''}`):null,
    trip.pending?Notice(trip.conflict?'This trip changed on another device. Choose which version to keep.':'Waiting to sync.',{tone:'alert'}):null,
    trip.conflict?ActionGroup(['local','cloud'].map(choice=>{const b=Button(choice==='local'?'Keep my change':'Use cloud version',{variant:'secondary',disabled:busy});b.addEventListener('click',()=>onResolve(choice));return b;})):null,
    trip.candidates.length&&!current?Note('Previous search — recheck'):null,
    current&&trip.summary?Text(trip.summary):null,
    trip.questions.length?Section([Heading('Needed to finish',3),...trip.questions.map(q=>Text(q))]):null,
    search||ActionGroup([copy]),open,
  ],{className:'trip-summary'});
  const candidates=rankCandidates(trip,now);
  const supported=candidates.filter(c=>c.fit==='match').length;
  const bookable=candidates.reduce((n,c)=>n+c.offers.filter(o=>offerState(trip,c,o,now)==='Observed offer — recheck before booking').length,0);
  const outcome=Section([Heading(bookable?`${bookable} observed matching offer${bookable===1?'':'s'}`:'No verified bookable match yet',3),Note(`${supported} configuration${supported===1?' meets':'s meet'} the requirements · ${candidates.length} researched`)]);
  const options=candidates.map(candidate=>ResultBlock({title:candidate.name,status:fitLabel[candidate.fit],detail:candidate.description,
    children:[candidate.url?Link('Hotel or itinerary details',candidate.url):null,
      ...candidate.offers.map(offer=>{
        const state=offerState(trip,candidate,offer,now);
        return Section([
          Stack([Strong(offer.channel),offer.total!==null?Strong(`${money(offer.total,offer.currency)}${offer.allIn?' total':' · incomplete total'}`):Strong('Price not checked')],{className:'trip-heading'}),
          Text(offer.product),Note(state),Note(when(offer.observedAt)),
          offer.terms?Text(offer.terms):null,
          offer.benefits?Note(`Conditional benefits: ${offer.benefits}`):null,
          offer.source?Link('Open offer to recheck',offer.source):null,
          Disclosure('Offer evidence',[Text(offer.evidence||'No live offer recorded.'),...checkRows(trip,offer.checks)])
        ],{className:'trip-offer'});
      }),
      !candidate.offers.length?Note('No dated offers'):null,
      Disclosure('Requirements and sources',checkRows(trip,candidate.checks))
    ]}));
  const coverage=tripCoverage(trip);
  const channels=Disclosure(`Search coverage · ${coverage.filter(c=>c.status!=='not-checked').length}/${coverage.length} sources attempted`,coverage.map(c=>Stack([
    Strong(c.label),Text(`${({'not-checked':'Not checked',partial:'Partly checked',checked:'Checked',login:'Sign-in needed',blocked:'Could not check'})[c.status]}${c.note?` — ${c.note}`:''}`),c.checkedAt?Note(when(c.checkedAt)):null,
    c.nextStep&&c.nextStep!==c.note?Text(c.nextStep):null,c.resumeURL?Link('Resume on provider',c.resumeURL):null,
    c.contextKey&&c.contextKey!==tripKey(trip)?Note('Request changed — restart this search'):null
  ],{className:'trip-check'})));
  return Stack([summary,outcome,channels,...options,!options.length?Note('No research saved'):null],{className:'trip-comparison'});
}
